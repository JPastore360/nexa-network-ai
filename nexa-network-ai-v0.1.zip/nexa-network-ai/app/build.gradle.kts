plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val nexaKeystorePath = System.getenv("NEXA_KEYSTORE_PATH")
val nexaSigningPassword = System.getenv("NEXA_SIGNING_PASSWORD")

android {
    namespace = "com.jpastore.nexanetwork"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jpastore.nexanetwork"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    val updateSigning = if (!nexaKeystorePath.isNullOrBlank() && !nexaSigningPassword.isNullOrBlank()) {
        signingConfigs.create("nexaUpdate") {
            storeFile = file(nexaKeystorePath)
            storePassword = nexaSigningPassword
            keyAlias = "nexa-network"
            keyPassword = nexaSigningPassword
        }
    } else null

    buildTypes {
        debug {
            if (updateSigning != null) signingConfig = updateSigning
        }
        release {
            if (updateSigning != null) signingConfig = updateSigning
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
