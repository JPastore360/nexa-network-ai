import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signingProps = Properties()
val signingPropsFile = rootProject.file("signing/signing.properties")
if (signingPropsFile.exists()) {
    signingPropsFile.inputStream().use { signingProps.load(it) }
}

val embeddedKeystore = rootProject.file("signing/nexa-update-key.jks")
val embeddedPassword = signingProps.getProperty("storePassword")
val embeddedAlias = signingProps.getProperty("keyAlias") ?: "nexa-network"
val embeddedKeyPassword = signingProps.getProperty("keyPassword") ?: embeddedPassword

val envKeystorePath = System.getenv("NEXA_KEYSTORE_PATH")
val envPassword = System.getenv("NEXA_SIGNING_PASSWORD")

android {
    namespace = "com.jpastore.nexanetwork"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jpastore.nexanetwork"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
    }

    val updateSigning = when {
        embeddedKeystore.exists() && !embeddedPassword.isNullOrBlank() -> {
            signingConfigs.create("nexaUpdate") {
                storeFile = embeddedKeystore
                storePassword = embeddedPassword
                keyAlias = embeddedAlias
                keyPassword = embeddedKeyPassword
            }
        }
        !envKeystorePath.isNullOrBlank() && !envPassword.isNullOrBlank() -> {
            signingConfigs.create("nexaUpdate") {
                storeFile = file(envKeystorePath)
                storePassword = envPassword
                keyAlias = "nexa-network"
                keyPassword = envPassword
            }
        }
        else -> null
    }

    buildTypes {
        debug {
            if (updateSigning != null) signingConfig = updateSigning
        }
        release {
            if (updateSigning != null) signingConfig = updateSigning
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
