# Nexa Network AI keeps the tunnel classes and Android entry points intact.
-keep class com.jpastore.nexanetwork.tunnel.** { *; }
-keep class com.jpastore.nexanetwork.MainActivity { *; }
-dontwarn org.jetbrains.annotations.**
