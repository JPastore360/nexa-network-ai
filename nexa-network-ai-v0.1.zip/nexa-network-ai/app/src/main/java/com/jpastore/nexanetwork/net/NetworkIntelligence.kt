package com.jpastore.nexanetwork.net

data class NetworkAssessment(
    val state: String,
    val detail: String,
    val severity: Int
)

object NetworkIntelligence {
    fun assess(metrics: PathMetrics, cellular: Boolean): NetworkAssessment {
        if (!metrics.available) {
            return NetworkAssessment("Indisponível", "Sem amostra válida no momento", 2)
        }

        val ping = metrics.latencyMs ?: 999.0
        val jitter = metrics.jitterMs ?: 999.0
        val loss = metrics.lossPct ?: 100.0
        val dbm = metrics.signalDbm

        if (cellular && dbm != null && dbm >= -95 && (ping >= 100.0 || jitter >= 35.0)) {
            return NetworkAssessment(
                "Sinal forte • congestionamento provável",
                "O rádio está bom ($dbm dBm), mas a resposta da rede está ruim. O gargalo provavelmente está além da antena.",
                2
            )
        }
        if (loss >= 3.0) {
            return NetworkAssessment("Perda de pacotes", "${fmt(loss)}% de perda detectada • pode causar travamentos e retransmissões", 3)
        }
        if (ping >= 140.0) {
            return NetworkAssessment("Alta latência", "Resposta de ${fmt(ping)} ms • navegação pode parecer lenta mesmo com bom sinal", 2)
        }
        if (jitter >= 35.0) {
            return NetworkAssessment("Instabilidade", "Jitter de ${fmt(jitter)} ms • chamadas e jogos podem oscilar", 2)
        }
        if (cellular && dbm != null && dbm <= -110) {
            return NetworkAssessment("Sinal fraco", "$dbm dBm • qualidade do rádio pode limitar a conexão", 2)
        }
        if (ping <= 45.0 && jitter <= 12.0 && loss <= 0.5) {
            return NetworkAssessment("Saudável", "Baixa latência, pouca variação e sem perda relevante", 0)
        }
        return NetworkAssessment("Estável", "Sem anomalia importante na amostra atual", 1)
    }

    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.1f", v)
}
