package com.jpastore.nexanetwork.dns

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import com.jpastore.nexanetwork.MainActivity
import com.jpastore.nexanetwork.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class NexaDnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.jpastore.nexanetwork.DNS_START"
        const val ACTION_STOP = "com.jpastore.nexanetwork.DNS_STOP"
        const val PREFS = "nexa_network"
        const val KEY_STATUS = "optimizer_status"
        const val KEY_ROUTE = "optimizer_route"
        const val KEY_AI = "optimizer_ai"
        const val KEY_POWER = "optimizer_power"
        const val KEY_COMPAT = "optimizer_compat"
        private const val CHANNEL_ID = "nexa_optimizer_active"
        private const val NOTIFICATION_ID = 7001
    }

    private val running = AtomicBoolean(false)
    private val consecutiveFailures = AtomicInteger(0)
    private val reader = Executors.newSingleThreadExecutor()
    private val resolvers = Executors.newFixedThreadPool(2)
    private var tun: android.os.ParcelFileDescriptor? = null
    private var input: FileInputStream? = null
    private var output: FileOutputStream? = null
    private var optimizer: DnsRouteOptimizer? = null
    private val outputLock = Any()

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOptimizer()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification("Iniciando otimização local…"))
        if (running.compareAndSet(false, true)) startOptimizer()
        return START_STICKY
    }

    override fun onDestroy() {
        stopOptimizer()
        reader.shutdownNow()
        resolvers.shutdownNow()
        super.onDestroy()
    }

    private fun startOptimizer() {
        try {
            val builder = Builder()
                .setSession("Nexa Network AI")
                .setMtu(1500)
                .addAddress("10.77.0.2", 32)
                .addRoute("10.77.0.1", 32)
                .addDnsServer("10.77.0.1")
                .allowBypass()

            val bypassed = mutableListOf<String>()
            listOf(
                "com.openai.chatgpt" to "ChatGPT",
                "com.whatsapp" to "WhatsApp",
                "com.whatsapp.w4b" to "WhatsApp Business"
            ).forEach { (pkg, label) ->
                try {
                    packageManager.getPackageInfo(pkg, 0)
                    builder.addDisallowedApplication(pkg)
                    bypassed += label
                } catch (_: Exception) {
                    // Aplicativo não instalado: não há nada a excluir.
                }
            }

            val descriptor = builder.establish() ?: error("Não foi possível iniciar a VPN local")
            tun = descriptor
            input = FileInputStream(descriptor.fileDescriptor)
            output = FileOutputStream(descriptor.fileDescriptor)

            val compatText = if (bypassed.isEmpty()) {
                "Split DNS ativo • tráfego normal fora do túnel"
            } else {
                "Split DNS ativo • bypass: ${bypassed.joinToString(", ")}"
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_COMPAT, compatText).apply()

            optimizer = DnsRouteOptimizer(this) { route, aiStatus, powerStatus ->
                val routeText = DnsRouteOptimizer.routeLabel(route)
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_ROUTE, routeText)
                    .putString(KEY_AI, aiStatus)
                    .putString(KEY_POWER, powerStatus)
                    .apply()
                updateStatus("Otimização ativa • $routeText")
            }.also { it.start() }

            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_AI, "IA local: aprendendo latência e estabilidade")
                .putString(KEY_POWER, "Economia adaptativa: iniciando")
                .apply()
            updateStatus("Otimização ativa • selecionando melhor DNS")
            reader.submit { readLoop() }
        } catch (e: Exception) {
            updateStatus("Falha ao iniciar: ${e.message ?: e.javaClass.simpleName}")
            stopOptimizer()
        }
    }

    private fun readLoop() {
        val localInput = input ?: return
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val len = localInput.read(buffer)
                if (len <= 0) continue
                val packet = buffer.copyOf(len)
                val query = DnsPacket.parseIpv4UdpDns(packet) ?: continue
                resolvers.submit { resolveAndReply(query) }
            } catch (_: Exception) {
                if (!running.get()) return
            }
        }
    }

    private fun resolveAndReply(query: DnsTunQuery) {
        val resolution = optimizer?.resolve(query.dnsPayload)
        if (resolution == null) {
            val failures = consecutiveFailures.incrementAndGet()
            if (failures >= 2 && running.get()) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_AI, "Failsafe: DNS não respondeu • VPN desativada para preservar Internet")
                    .apply()
                updateStatus("Failsafe acionado • restaurando conexão normal")
                stopOptimizer()
            }
            return
        }
        consecutiveFailures.set(0)
        val responsePacket = DnsPacket.buildIpv4UdpResponse(query, resolution.payload)
        synchronized(outputLock) {
            try {
                output?.write(responsePacket)
                output?.flush()
            } catch (_: Exception) {}
        }
        val routeText = DnsRouteOptimizer.routeLabel(resolution.route)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ROUTE, routeText).apply()
    }

    private fun stopOptimizer() {
        if (!running.getAndSet(false) && tun == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        optimizer?.stop()
        optimizer = null
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { tun?.close() } catch (_: Exception) {}
        input = null
        output = null
        tun = null
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STATUS, "Desativado")
            .apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateStatus(status: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATUS, status).apply()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(status))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Nexa Network • otimização ativa",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Indica quando DNS inteligente, IA local e failsafe estão ativos"
                enableLights(false)
                enableVibration(false)
                setShowBadge(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(status: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPi = PendingIntent.getActivity(
            this,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, NexaDnsVpnService::class.java).setAction(ACTION_STOP)
        val stopPi = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(R.drawable.ic_nexa_status, "Parar", stopPi).build()

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Nexa Network AI • LIGADO")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_nexa_status)
            .setColor(Color.rgb(0, 200, 255))
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(action)
            .build()
    }
}
