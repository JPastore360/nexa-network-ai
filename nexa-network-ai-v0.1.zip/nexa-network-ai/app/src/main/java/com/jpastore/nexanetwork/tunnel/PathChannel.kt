package com.jpastore.nexanetwork.tunnel

import android.net.Network
import android.net.VpnService
import com.jpastore.nexanetwork.crypto.TunnelCodec
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class PathChannel(
    private val service: VpnService,
    val pathId: Byte,
    val network: Network,
    private val endpoint: InetSocketAddress,
    private val passphrase: String,
    private val session: Long,
    private val nextSeq: () -> Long,
    private val onData: (ByteArray) -> Unit
) {
    private val socket = DatagramSocket()
    private val running = AtomicBoolean(false)
    private val worker = Executors.newSingleThreadExecutor()
    private val heartbeat = Executors.newSingleThreadScheduledExecutor()
    private var heartbeatTask: ScheduledFuture<*>? = null
    private val lastPongMs = AtomicLong(0)
    private val smoothedRttBits = AtomicLong(java.lang.Double.doubleToLongBits(999.0))

    fun start() {
        service.protect(socket)
        network.bindSocket(socket)
        socket.connect(endpoint)
        socket.soTimeout = 1500
        running.set(true)
        worker.submit { receiveLoop() }
        heartbeatTask = heartbeat.scheduleWithFixedDelay({ sendPing() }, 0, 3, TimeUnit.SECONDS)
    }

    fun stop() {
        running.set(false)
        heartbeatTask?.cancel(true)
        socket.close()
        worker.shutdownNow()
        heartbeat.shutdownNow()
    }

    fun isHealthy(): Boolean {
        val pong = lastPongMs.get()
        return pong == 0L || System.currentTimeMillis() - pong < 10_000
    }

    fun rttMs(): Double = java.lang.Double.longBitsToDouble(smoothedRttBits.get())

    fun sendData(payload: ByteArray): Boolean {
        return send(TunnelCodec.TYPE_DATA, payload)
    }

    private fun sendPing() {
        val payload = ByteBuffer.allocate(8).order(ByteOrder.BIG_ENDIAN).putLong(System.nanoTime()).array()
        send(TunnelCodec.TYPE_PING, payload)
    }

    private fun send(type: Byte, payload: ByteArray): Boolean {
        if (!running.get()) return false
        return try {
            val encoded = TunnelCodec.encode(passphrase, type, pathId, session, nextSeq(), 0, payload)
            socket.send(DatagramPacket(encoded, encoded.size))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun receiveLoop() {
        val buffer = ByteArray(65535)
        while (running.get()) {
            try {
                val packet = DatagramPacket(buffer, buffer.size)
                socket.receive(packet)
                val data = packet.data.copyOfRange(packet.offset, packet.offset + packet.length)
                val msg = TunnelCodec.decode(passphrase, data, 1) ?: continue
                if (msg.session != session) continue
                when (msg.type) {
                    TunnelCodec.TYPE_DATA -> onData(msg.payload)
                    TunnelCodec.TYPE_PONG -> handlePong(msg.payload)
                }
            } catch (_: java.net.SocketTimeoutException) {
                // heartbeat health check handles this
            } catch (_: Exception) {
                if (!running.get()) return
            }
        }
    }

    private fun handlePong(payload: ByteArray) {
        if (payload.size != 8) return
        val sentNs = ByteBuffer.wrap(payload).order(ByteOrder.BIG_ENDIAN).long
        val rtt = (System.nanoTime() - sentNs) / 1_000_000.0
        val old = rttMs()
        val next = if (old >= 900) rtt else old * 0.75 + rtt * 0.25
        smoothedRttBits.set(java.lang.Double.doubleToLongBits(next))
        lastPongMs.set(System.currentTimeMillis())
    }
}
