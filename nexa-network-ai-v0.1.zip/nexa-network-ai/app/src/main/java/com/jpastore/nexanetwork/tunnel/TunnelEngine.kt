package com.jpastore.nexanetwork.tunnel

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class TunnelEngine(
    private val service: VpnService,
    private val tun: ParcelFileDescriptor,
    private val endpoint: InetSocketAddress,
    private val passphrase: String,
    private val onNetworksChanged: (Array<Network>) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val cm = service.getSystemService(ConnectivityManager::class.java)
    private val running = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()
    private val seq = AtomicLong(1)
    private val session = java.security.SecureRandom().nextLong()
    private val output = FileOutputStream(tun.fileDescriptor)
    private val input = FileInputStream(tun.fileDescriptor)
    private val outputLock = Any()

    @Volatile private var wifiChannel: PathChannel? = null
    @Volatile private var cellChannel: PathChannel? = null
    @Volatile private var wifiNetwork: Network? = null
    @Volatile private var cellNetwork: Network? = null

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { setWifi(network) }
        override fun onLost(network: Network) { if (wifiNetwork == network) setWifi(null) }
    }
    private val cellCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { setCell(network) }
        override fun onLost(network: Network) { if (cellNetwork == network) setCell(null) }
    }

    fun start() {
        if (!running.compareAndSet(false, true)) return
        val wifiRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cellRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        try { cm.requestNetwork(wifiRequest, wifiCallback) } catch (_: Exception) {}
        try { cm.requestNetwork(cellRequest, cellCallback) } catch (_: Exception) {}
        executor.submit { tunReadLoop() }
    }

    fun stop() {
        running.set(false)
        try { cm.unregisterNetworkCallback(wifiCallback) } catch (_: Exception) {}
        try { cm.unregisterNetworkCallback(cellCallback) } catch (_: Exception) {}
        wifiChannel?.stop()
        cellChannel?.stop()
        try { input.close() } catch (_: Exception) {}
        try { output.close() } catch (_: Exception) {}
        try { tun.close() } catch (_: Exception) {}
        executor.shutdownNow()
    }

    @Synchronized
    private fun setWifi(network: Network?) {
        if (!running.get() || network == wifiNetwork) return
        wifiChannel?.stop()
        wifiNetwork = network
        wifiChannel = network?.let { createChannel(1, it) }
        publishNetworks()
    }

    @Synchronized
    private fun setCell(network: Network?) {
        if (!running.get() || network == cellNetwork) return
        cellChannel?.stop()
        cellNetwork = network
        cellChannel = network?.let { createChannel(2, it) }
        publishNetworks()
    }

    private fun publishNetworks() {
        val networks = listOfNotNull(wifiNetwork, cellNetwork).toTypedArray()
        if (networks.isNotEmpty()) onNetworksChanged(networks)
        onStatus(
            when {
                wifiNetwork != null && cellNetwork != null -> "Smart Multipath ativo • Wi‑Fi + celular"
                wifiNetwork != null -> "Túnel ativo • Wi‑Fi"
                cellNetwork != null -> "Túnel ativo • celular"
                else -> "Aguardando rede disponível"
            }
        )
    }

    private fun createChannel(id: Int, network: Network): PathChannel {
        return PathChannel(
            service = service,
            pathId = id.toByte(),
            network = network,
            endpoint = endpoint,
            passphrase = passphrase,
            session = session,
            nextSeq = { seq.getAndIncrement() },
            onData = { data ->
                synchronized(outputLock) {
                    try {
                        output.write(data)
                        output.flush()
                    } catch (_: Exception) {}
                }
            }
        ).also { it.start() }
    }

    private fun tunReadLoop() {
        val buffer = ByteArray(32767)
        while (running.get()) {
            try {
                val len = input.read(buffer)
                if (len <= 0) continue
                val packet = buffer.copyOf(len)
                val channel = chooseChannel(packet)
                if (channel?.sendData(packet) != true) {
                    fallback(channel)?.sendData(packet)
                }
            } catch (_: Exception) {
                if (!running.get()) return
            }
        }
    }

    private fun chooseChannel(packet: ByteArray): PathChannel? {
        val wifi = wifiChannel?.takeIf { it.isHealthy() }
        val cell = cellChannel?.takeIf { it.isHealthy() }
        if (wifi == null) return cell
        if (cell == null) return wifi

        val wrtt = wifi.rttMs().coerceAtLeast(5.0)
        val crtt = cell.rttMs().coerceAtLeast(5.0)
        val wifiWeight = (1.0 / wrtt) / ((1.0 / wrtt) + (1.0 / crtt))
        val bucket = abs(PacketFlow.stableHash(packet) % 100)
        return if (bucket < (wifiWeight * 100.0).toInt().coerceIn(20, 80)) wifi else cell
    }

    private fun fallback(selected: PathChannel?): PathChannel? {
        val wifi = wifiChannel?.takeIf { it !== selected && it.isHealthy() }
        val cell = cellChannel?.takeIf { it !== selected && it.isHealthy() }
        return wifi ?: cell
    }
}
