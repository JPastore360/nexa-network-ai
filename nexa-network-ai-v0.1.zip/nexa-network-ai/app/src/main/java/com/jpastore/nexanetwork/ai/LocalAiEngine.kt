package com.jpastore.nexanetwork.ai

import android.content.Context
import com.jpastore.nexanetwork.power.PowerState
import com.jpastore.nexanetwork.AppSettings
import com.jpastore.nexanetwork.NexaMode
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class AiCandidate(
    val provider: String,
    val networkLabel: String,
    val rttMs: Double,
    val cellular: Boolean
)

data class AiChoice(
    val provider: String,
    val networkLabel: String,
    val confidence: Int,
    val reason: String,
    val score: Double
)

/**
 * Motor adaptativo local. Não usa IA em nuvem nem envia telemetria.
 * Aprende uma média móvel de latência/sucesso por DNS + tipo de rede e usa
 * esse histórico junto com a medição atual e o estado de energia.
 */
class LocalAiEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexa_ai_local", Context.MODE_PRIVATE)

    fun record(provider: String, networkLabel: String, rttMs: Double?, success: Boolean) {
        val key = key(provider, networkLabel)
        val oldRtt = prefs.getFloat("${key}_rtt", -1f).toDouble()
        val oldSuccess = prefs.getFloat("${key}_ok", 0.85f).toDouble()
        val newSuccess = (oldSuccess * 0.88 + (if (success) 1.0 else 0.0) * 0.12).coerceIn(0.0, 1.0)
        val edit = prefs.edit().putFloat("${key}_ok", newSuccess.toFloat())
        if (success && rttMs != null) {
            val newRtt = if (oldRtt <= 0) rttMs else oldRtt * 0.78 + rttMs * 0.22
            edit.putFloat("${key}_rtt", newRtt.toFloat())
        }
        edit.apply()
    }

    fun choose(candidates: List<AiCandidate>, power: PowerState): AiChoice? {
        if (candidates.isEmpty()) return null
        val ranked = candidates.map { c ->
            val key = key(c.provider, c.networkLabel)
            val historicRtt = prefs.getFloat("${key}_rtt", c.rttMs.toFloat()).toDouble().coerceAtLeast(1.0)
            val success = prefs.getFloat("${key}_ok", 0.85f).toDouble().coerceIn(0.0, 1.0)

            // Medição atual pesa mais que o histórico. Celular recebe pequena penalização
            // quando a bateria está baixa ou a tela está apagada para evitar manter rádio acordado.
            val mode = AppSettings(context).mode()
            val currentWeight = when (mode) {
                NexaMode.LATENCY -> 0.84
                NexaMode.NAVIGATION -> 0.74
                NexaMode.ECONOMY -> 0.58
                NexaMode.PRIVACY -> 0.62
                else -> 0.68
            }
            val learnedLatency = c.rttMs * currentWeight + historicRtt * (1.0 - currentWeight)
            val reliabilityPenalty = (1.0 - success) * when (mode) {
                NexaMode.NAVIGATION -> 180.0
                NexaMode.PRIVACY -> 165.0
                else -> 140.0
            }
            val basePowerPenalty = when {
                !c.cellular -> 0.0
                power.batteryPct <= 15 -> 45.0
                !power.interactive -> 28.0
                power.batteryPct <= 30 -> 18.0
                else -> 8.0
            }
            val powerPenalty = when (mode) {
                NexaMode.LATENCY -> basePowerPenalty * 0.35
                NexaMode.ECONOMY -> basePowerPenalty * 2.2
                NexaMode.PRIVACY -> basePowerPenalty * 1.35
                else -> basePowerPenalty
            }
            Triple(c, learnedLatency + reliabilityPenalty + powerPenalty, success)
        }.sortedBy { it.second }

        val best = ranked.first()
        val second = ranked.getOrNull(1)
        val gap = second?.let { (it.second - best.second).coerceAtLeast(0.0) } ?: 40.0
        val confidence = (60.0 + min(30.0, gap) + best.third * 10.0).toInt().coerceIn(55, 99)
        val reason = buildString {
            append("${best.first.provider} em ${best.first.networkLabel}")
            append(" • ${String.format(Locale.US, "%.0f", best.first.rttMs)} ms")
            if (best.first.cellular && power.batteryPct <= 30) append(" • celular só valeu a troca apesar da economia")
            else if (!best.first.cellular) append(" • prioriza estabilidade e bateria")
            else append(" • menor resposta no momento")
        }
        return AiChoice(best.first.provider, best.first.networkLabel, confidence, reason, best.second)
    }

    fun summary(choice: AiChoice?, power: PowerState): String {
        if (choice == null) return "IA local: aguardando amostras • ${power.label}"
        return "IA local: ${choice.reason}\nConfiança ${choice.confidence}% • ${power.label}"
    }

    private fun key(provider: String, networkLabel: String): String =
        (provider + "_" + networkLabel).lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_")
}
