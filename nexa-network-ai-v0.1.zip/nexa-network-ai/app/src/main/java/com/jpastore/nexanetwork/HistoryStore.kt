package com.jpastore.nexanetwork

import android.content.Context
import com.jpastore.nexanetwork.net.NetworkSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_history_local", Context.MODE_PRIVATE)
    private val settings = AppSettings(context)

    data class Entry(
        val timestamp: Long,
        val wifiScore: Int,
        val cellScore: Int,
        val wifiPing: Double?,
        val cellPing: Double?,
        val radio: String,
        val recommendation: String
    )

    fun record(snapshot: NetworkSnapshot) {
        if (!settings.keepHistory()) return
        val last = prefs.getLong("last_record", 0L)
        val now = System.currentTimeMillis()
        if (now - last < 45_000L) return
        val entry = Entry(
            now,
            snapshot.wifi.score(),
            snapshot.cellular.score(),
            snapshot.wifi.latencyMs,
            snapshot.cellular.latencyMs,
            snapshot.radioGeneration,
            snapshot.recommendation.replace("\n", " ").replace("|", "/")
        )
        val lines = prefs.getString("entries", "").orEmpty().lineSequence().filter { it.isNotBlank() }.toMutableList()
        lines += encode(entry)
        while (lines.size > 80) lines.removeAt(0)
        prefs.edit().putString("entries", lines.joinToString("\n")).putLong("last_record", now).apply()
    }

    fun entries(): List<Entry> = prefs.getString("entries", "").orEmpty()
        .lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).toList().asReversed()

    fun clear() = prefs.edit().clear().apply()

    fun formatTime(timestamp: Long): String = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(timestamp))

    private fun encode(e: Entry): String = listOf(
        e.timestamp,
        e.wifiScore,
        e.cellScore,
        e.wifiPing ?: -1.0,
        e.cellPing ?: -1.0,
        e.radio,
        e.recommendation
    ).joinToString("|")

    private fun decode(line: String): Entry? = runCatching {
        val p = line.split('|', limit = 7)
        Entry(
            p[0].toLong(), p[1].toInt(), p[2].toInt(),
            p[3].toDouble().takeIf { it >= 0 }, p[4].toDouble().takeIf { it >= 0 },
            p[5], p[6]
        )
    }.getOrNull()
}
