package com.jpastore.nexanetwork

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.jpastore.nexanetwork.R

class SplashActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 9, 14)
        window.navigationBarColor = Color.rgb(4, 9, 14)
        setContentView(buildSplash())
        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1150)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun buildSplash(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(28), dp(28), dp(28), dp(28))
        setBackgroundColor(Color.rgb(4, 9, 14))

        addView(ImageView(this@SplashActivity).apply {
            setImageResource(R.drawable.ic_nexa_logo)
            layoutParams = LinearLayout.LayoutParams(dp(104), dp(104))
            alpha = 0f
            scaleX = .90f
            scaleY = .90f
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).start()
        })
        addView(space(20))
        addView(label("NEXA", 31, true, Color.WHITE))
        addView(label("NETWORK AI", 18, true, Color.rgb(0, 200, 255)))
        addView(space(8))
        addView(label("Conectividade inteligente no seu aparelho", 12, false, Color.rgb(145, 164, 184)))
        addView(space(28))
        addView(ProgressBar(this@SplashActivity).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(37, 235, 125))
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32))
        })
        addView(space(14))
        addView(label("Preparando diagnóstico e otimização…", 11, false, Color.rgb(118, 139, 156)))
    }

    private fun label(value: String, size: Int, bold: Boolean, color: Int) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun space(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
