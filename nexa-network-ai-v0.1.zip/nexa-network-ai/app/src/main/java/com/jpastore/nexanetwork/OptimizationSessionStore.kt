package com.jpastore.nexanetwork

import android.content.Context
import com.jpastore.nexanetwork.net.NetworkSnapshot

class OptimizationSessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_optimization_session", Context.MODE_PRIVATE)

    data class Baseline(
        val timestamp: Long,
        val wifiScore: Int,
        val cellScore: Int,
        val wifiPing: Double?,
        val cellPing: Double?
    )

    fun capture(snapshot: NetworkSnapshot?) {
        if (snapshot == null) return
        prefs.edit()
            .putLong("time", System.currentTimeMillis())
            .putInt("wifi_score", snapshot.wifi.score())
            .putInt("cell_score", snapshot.cellular.score())
            .putLong("wifi_ping_bits", (snapshot.wifi.latencyMs ?: -1.0).toBits())
            .putLong("cell_ping_bits", (snapshot.cellular.latencyMs ?: -1.0).toBits())
            .apply()
    }

    fun baseline(): Baseline? {
        val timestamp = prefs.getLong("time", 0L)
        if (timestamp <= 0L) return null
        fun ping(key: String): Double? {
            val value = Double.fromBits(prefs.getLong(key, (-1.0).toBits()))
            return value.takeIf { it >= 0.0 }
        }
        return Baseline(
            timestamp,
            prefs.getInt("wifi_score", 0),
            prefs.getInt("cell_score", 0),
            ping("wifi_ping_bits"),
            ping("cell_ping_bits")
        )
    }

    fun clear() = prefs.edit().clear().apply()
}
