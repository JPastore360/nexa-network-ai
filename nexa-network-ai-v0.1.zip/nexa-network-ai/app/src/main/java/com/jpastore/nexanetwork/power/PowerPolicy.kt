package com.jpastore.nexanetwork.power

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import com.jpastore.nexanetwork.AppSettings
import com.jpastore.nexanetwork.NexaMode

data class PowerState(
    val batteryPct: Int,
    val interactive: Boolean,
    val charging: Boolean,
    val probeIntervalSeconds: Long,
    val monitorIntervalSeconds: Long,
    val label: String
)

class PowerPolicy(private val context: Context) {
    fun current(): PowerState {
        val batteryManager = context.getSystemService(BatteryManager::class.java)
        val powerManager = context.getSystemService(PowerManager::class.java)
        val pct = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            ?.takeIf { it in 0..100 } ?: 100
        val charging = batteryManager?.isCharging == true
        val interactive = powerManager?.isInteractive != false

        val mode = AppSettings(context).mode()
        if (mode == NexaMode.ECONOMY) {
            return when {
                charging -> PowerState(pct, interactive, true, 75, 18, "Economia • carregando")
                !interactive -> PowerState(pct, false, false, 300, 60, "Economia máxima em segundo plano")
                else -> PowerState(pct, true, false, 150, 30, "Modo Economia")
            }
        }
        if (mode == NexaMode.LATENCY && interactive && pct > 20) {
            return PowerState(pct, true, charging, 24, 6, "Baixa latência • medições rápidas")
        }
        if (mode == NexaMode.PRIVACY) {
            return PowerState(pct, interactive, charging, if (interactive) 110 else 240, if (interactive) 24 else 50, "Privacidade máxima • menos sondagens")
        }
        if (mode == NexaMode.NAVIGATION && interactive) {
            return PowerState(pct, true, charging, 42, 9, "Navegação • DNS responsivo")
        }
        return when {
            charging -> PowerState(pct, interactive, true, 35, 8, "Desempenho enquanto carrega")
            pct <= 15 -> PowerState(pct, interactive, false, 240, 45, "Economia forte • bateria baixa")
            !interactive -> PowerState(pct, false, false, 150, 30, "Economia em segundo plano")
            pct <= 30 -> PowerState(pct, true, false, 90, 18, "Economia adaptativa")
            else -> PowerState(pct, true, false, 55, 10, "Equilíbrio inteligente")
        }
    }
}
