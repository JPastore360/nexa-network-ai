package com.jpastore.nexanetwork.net

import android.net.Network

data class PathMetrics(
    val network: Network? = null,
    val available: Boolean = false,
    val label: String = "Indisponível",
    val latencyMs: Double? = null,
    val jitterMs: Double? = null,
    val lossPct: Double? = null,
    val signalDbm: Int? = null,
    val detail: String = ""
) {
    fun score(): Int {
        if (!available) return 0
        val latency = latencyMs ?: 150.0
        val jitter = jitterMs ?: 40.0
        val loss = lossPct ?: 5.0
        val latencyScore = (100.0 - latency.coerceIn(0.0, 120.0) / 120.0 * 100.0)
        val jitterScore = (100.0 - jitter.coerceIn(0.0, 50.0) / 50.0 * 100.0)
        val lossScore = (100.0 - loss.coerceIn(0.0, 10.0) / 10.0 * 100.0)
        return (latencyScore * 0.5 + jitterScore * 0.25 + lossScore * 0.25).toInt().coerceIn(0, 100)
    }
}

data class NetworkSnapshot(
    val wifi: PathMetrics = PathMetrics(label = "Wi‑Fi"),
    val cellular: PathMetrics = PathMetrics(label = "Celular"),
    val radioGeneration: String = "—",
    val radioDetail: String = "",
    val recommendation: String = "Aguardando medições"
)
