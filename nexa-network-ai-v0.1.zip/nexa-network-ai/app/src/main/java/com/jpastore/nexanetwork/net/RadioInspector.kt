package com.jpastore.nexanetwork.net

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager

class RadioInspector(private val context: Context) {
    private val telephony = context.getSystemService(TelephonyManager::class.java)
    @Volatile private var displayOverride: Int = TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NONE

    private var callback: TelephonyCallback? = null

    fun start() {
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = object : TelephonyCallback(), TelephonyCallback.DisplayInfoListener {
                override fun onDisplayInfoChanged(info: TelephonyDisplayInfo) {
                    displayOverride = info.overrideNetworkType
                }
            }
            callback = cb
            try { telephony.registerTelephonyCallback(context.mainExecutor, cb) } catch (_: Exception) {}
        }
    }

    fun stop() {
        if (Build.VERSION.SDK_INT >= 31) {
            callback?.let { try { telephony.unregisterTelephonyCallback(it) } catch (_: Exception) {} }
        }
        callback = null
    }

    @Suppress("DEPRECATION")
    fun generation(): String {
        if (Build.VERSION.SDK_INT >= 31) {
            if (displayOverride == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA ||
                displayOverride == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED) {
                return "5G"
            }
        }
        if (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return "Permissão necessária"
        }
        return try {
            when (telephony.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_GPRS,
                TelephonyManager.NETWORK_TYPE_EDGE,
                TelephonyManager.NETWORK_TYPE_GSM,
                TelephonyManager.NETWORK_TYPE_CDMA,
                TelephonyManager.NETWORK_TYPE_1xRTT,
                TelephonyManager.NETWORK_TYPE_IDEN -> "2G"

                TelephonyManager.NETWORK_TYPE_UMTS,
                TelephonyManager.NETWORK_TYPE_EVDO_0,
                TelephonyManager.NETWORK_TYPE_EVDO_A,
                TelephonyManager.NETWORK_TYPE_EVDO_B,
                TelephonyManager.NETWORK_TYPE_HSDPA,
                TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_HSPAP,
                TelephonyManager.NETWORK_TYPE_EHRPD,
                TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "3G"

                TelephonyManager.NETWORK_TYPE_LTE -> "4G"
                TelephonyManager.NETWORK_TYPE_NR -> "5G"
                else -> "Celular"
            }
        } catch (_: Exception) {
            "Celular"
        }
    }

    private fun readNrMetric(signal: Any, getter: String): Int? {
        return try {
            val value = signal.javaClass.getMethod(getter).invoke(signal) as? Int
            value?.takeUnless { it == Int.MAX_VALUE }
        } catch (_: Exception) {
            null
        }
    }

    fun detailedSignal(): Pair<Int?, String> {
        val fine = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine) return null to "Sinal detalhado requer localização precisa apenas para leitura da célula"
        return try {
            val registered = telephony.allCellInfo?.firstOrNull { it.isRegistered }
            when (registered) {
                is CellInfoNr -> {
                    if (Build.VERSION.SDK_INT >= 29) {
                        val s = registered.cellSignalStrength
                        val ssRsrp = readNrMetric(s, "getSsRsrp")
                        val ssRsrq = readNrMetric(s, "getSsRsrq")
                        val ssSinr = readNrMetric(s, "getSsSinr")
                        val detail = buildString {
                            append("5G NR")
                            ssRsrp?.let { append(" • SS-RSRP $it dBm") }
                            ssRsrq?.let { append(" • SS-RSRQ $it dB") }
                            ssSinr?.let { append(" • SS-SINR $it dB") }
                            if (ssRsrp == null && ssRsrq == null && ssSinr == null) {
                                append(" • ${s.dbm} dBm")
                            }
                        }
                        s.dbm to detail
                    } else null to "5G NR"
                }
                is CellInfoLte -> {
                    val s = registered.cellSignalStrength
                    s.dbm to "4G LTE • RSRP ${s.rsrp} dBm • RSRQ ${s.rsrq} dB • RSSNR ${s.rssnr}"
                }
                is CellInfoWcdma -> {
                    val s = registered.cellSignalStrength
                    s.dbm to "3G WCDMA • ${s.dbm} dBm"
                }
                is CellInfoGsm -> {
                    val s = registered.cellSignalStrength
                    s.dbm to "2G GSM • ${s.dbm} dBm"
                }
                else -> null to "Métrica de rádio indisponível neste modem"
            }
        } catch (e: Exception) {
            null to "Métrica de rádio indisponível: ${e.javaClass.simpleName}"
        }
    }
}
