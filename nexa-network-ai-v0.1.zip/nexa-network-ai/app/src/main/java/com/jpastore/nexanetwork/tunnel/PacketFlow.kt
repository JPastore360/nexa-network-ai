package com.jpastore.nexanetwork.tunnel

object PacketFlow {
    fun stableHash(packet: ByteArray): Int {
        if (packet.size < 20) return packet.contentHashCode()
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return packet.contentHashCode()
        val ihl = (packet[0].toInt() and 0x0F) * 4
        if (ihl < 20 || packet.size < ihl) return packet.contentHashCode()
        var h = 17
        for (i in 12..19) h = 31 * h + packet[i]
        h = 31 * h + packet[9]
        val protocol = packet[9].toInt() and 0xFF
        if ((protocol == 6 || protocol == 17) && packet.size >= ihl + 4) {
            for (i in ihl until ihl + 4) h = 31 * h + packet[i]
        }
        return h
    }
}
