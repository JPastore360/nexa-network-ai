package com.jpastore.nexanetwork.dns

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import kotlin.random.Random

data class DnsRoute(
    val network: Network?,
    val networkLabel: String,
    val serverName: String,
    val serverAddress: InetAddress,
    val rttMs: Double
)

data class DnsResolution(
    val payload: ByteArray,
    val route: DnsRoute,
    val rttMs: Double
)

class DnsRouteOptimizer(
    private val service: VpnService,
    private val onRouteChanged: (DnsRoute?) -> Unit
) {
    private data class Provider(val name: String, val ip: String)

    private val cm = service.getSystemService(ConnectivityManager::class.java)
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private var probeTask: ScheduledFuture<*>? = null

    @Volatile private var wifiNetwork: Network? = null
    @Volatile private var cellNetwork: Network? = null
    @Volatile private var bestRoute: DnsRoute? = null

    private val providers = listOf(
        Provider("Cloudflare", "1.1.1.1"),
        Provider("Google", "8.8.8.8"),
        Provider("Quad9", "9.9.9.9")
    )

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            wifiNetwork = network
            scheduleProbeSoon()
        }

        override fun onLost(network: Network) {
            if (wifiNetwork == network) wifiNetwork = null
            scheduleProbeSoon()
        }

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifiNetwork = network
        }
    }

    private val cellCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            cellNetwork = network
            scheduleProbeSoon()
        }

        override fun onLost(network: Network) {
            if (cellNetwork == network) cellNetwork = null
            scheduleProbeSoon()
        }

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) cellNetwork = network
        }
    }

    fun start() {
        val wifiRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cellRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()

        try { cm.requestNetwork(wifiRequest, wifiCallback) } catch (_: Exception) {}
        try { cm.requestNetwork(cellRequest, cellCallback) } catch (_: Exception) {}

        probeTask = scheduler.scheduleWithFixedDelay(
            { probeBestRoute() },
            0,
            20,
            TimeUnit.SECONDS
        )
    }

    fun stop() {
        probeTask?.cancel(true)
        try { cm.unregisterNetworkCallback(wifiCallback) } catch (_: Exception) {}
        try { cm.unregisterNetworkCallback(cellCallback) } catch (_: Exception) {}
        scheduler.shutdownNow()
    }

    fun currentRoute(): DnsRoute? = bestRoute

    fun resolve(payload: ByteArray): DnsResolution? {
        val best = bestRoute
        val combinations = mutableListOf<Triple<Network?, String, Provider>>()

        if (best != null) {
            val provider = providers.firstOrNull { it.name == best.serverName }
            if (provider != null) combinations += Triple(best.network, best.networkLabel, provider)
        }

        val wifi = wifiNetwork
        val cell = cellNetwork
        for (provider in providers) {
            if (wifi != null) combinations += Triple(wifi, "Wi‑Fi", provider)
            if (cell != null) combinations += Triple(cell, "Celular", provider)
        }
        if (wifi == null && cell == null) {
            for (provider in providers) combinations += Triple(null, "Rede padrão", provider)
        }

        val seen = HashSet<String>()
        val attempts = combinations.filter { (network, label, provider) ->
            seen.add("${network?.toString() ?: "default"}|$label|${provider.ip}")
        }.take(4)

        for ((network, label, provider) in attempts) {
            val address = runCatching { InetAddress.getByName(provider.ip) }.getOrNull() ?: continue
            val result = exchange(network, address, payload, 950) ?: continue
            val route = DnsRoute(network, label, provider.name, address, result.second)
            val old = bestRoute
            if (old == null || result.second + 8.0 < old.rttMs) {
                bestRoute = route
                onRouteChanged(route)
            }
            return DnsResolution(result.first, route, result.second)
        }
        return null
    }

    private fun probeBestRoute() {
        val candidates = mutableListOf<Pair<Network?, String>>()
        wifiNetwork?.let { candidates += it to "Wi‑Fi" }
        cellNetwork?.let { candidates += it to "Celular" }
        if (candidates.isEmpty()) candidates += null to "Rede padrão"

        val query = DnsPacket.buildProbeQuery(Random.nextInt(0, 65536))
        var winner: DnsRoute? = null
        var winnerScore = Double.MAX_VALUE

        for ((network, label) in candidates) {
            for (provider in providers) {
                val address = runCatching { InetAddress.getByName(provider.ip) }.getOrNull() ?: continue
                val result = exchange(network, address, query, 700) ?: continue
                if (!DnsPacket.responseMatchesQuery(query, result.first)) continue
                val bias = if (label == "Celular") 8.0 else 0.0
                val score = result.second + bias
                if (score < winnerScore) {
                    winnerScore = score
                    winner = DnsRoute(network, label, provider.name, address, result.second)
                }
            }
        }

        val old = bestRoute
        bestRoute = winner
        if (old?.serverName != winner?.serverName ||
            old?.networkLabel != winner?.networkLabel ||
            kotlin.math.abs((old?.rttMs ?: -1.0) - (winner?.rttMs ?: -1.0)) >= 4.0
        ) {
            onRouteChanged(winner)
        }
    }

    private fun scheduleProbeSoon() {
        if (scheduler.isShutdown) return
        scheduler.schedule({ probeBestRoute() }, 500, TimeUnit.MILLISECONDS)
    }

    private fun exchange(
        network: Network?,
        server: InetAddress,
        payload: ByteArray,
        timeoutMs: Int
    ): Pair<ByteArray, Double>? {
        val socket = DatagramSocket()
        return try {
            service.protect(socket)
            if (network != null) network.bindSocket(socket)
            socket.soTimeout = timeoutMs
            socket.connect(server, 53)
            val start = System.nanoTime()
            socket.send(DatagramPacket(payload, payload.size))
            val buffer = ByteArray(4096)
            val response = DatagramPacket(buffer, buffer.size)
            socket.receive(response)
            val elapsed = (System.nanoTime() - start) / 1_000_000.0
            val body = response.data.copyOfRange(response.offset, response.offset + response.length)
            if (!DnsPacket.responseMatchesQuery(payload, body)) null else body to elapsed
        } catch (_: Exception) {
            null
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    companion object {
        fun routeLabel(route: DnsRoute?): String {
            if (route == null) return "Procurando melhor DNS…"
            return "${route.serverName} • ${route.networkLabel} • ${route.rttMs.roundToInt()} ms"
        }
    }
}
