package com.jpastore.nexanetwork.dns

import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import com.jpastore.nexanetwork.ai.AiCandidate
import com.jpastore.nexanetwork.ai.LocalAiEngine
import com.jpastore.nexanetwork.power.PowerPolicy
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import kotlin.random.Random

data class DnsRoute(
    val network: Network?,
    val networkLabel: String,
    val serverName: String,
    val serverAddress: InetAddress,
    val rttMs: Double,
    val protocol: String = "DoH"
)

data class DnsResolution(
    val payload: ByteArray,
    val route: DnsRoute,
    val rttMs: Double
)

class DnsRouteOptimizer(
    private val service: VpnService,
    private val onRouteChanged: (route: DnsRoute?, aiStatus: String, powerStatus: String) -> Unit
) {
    private data class Provider(
        val name: String,
        val ip: String,
        val host: String,
        val path: String = "/dns-query"
    )

    private val cm = service.getSystemService(ConnectivityManager::class.java)
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private val ai = LocalAiEngine(service)
    private val powerPolicy = PowerPolicy(service)
    private var probeTask: ScheduledFuture<*>? = null

    @Volatile private var wifiNetwork: Network? = null
    @Volatile private var cellNetwork: Network? = null
    @Volatile private var bestRoute: DnsRoute? = null
    @Volatile private var lastAiStatus: String = "IA local: aguardando amostras"
    @Volatile private var lastPowerStatus: String = "Economia adaptativa"

    private val providers = listOf(
        Provider("Cloudflare", "1.1.1.1", "cloudflare-dns.com"),
        Provider("Google", "8.8.8.8", "dns.google"),
        Provider("Quad9", "9.9.9.9", "dns.quad9.net")
    )

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            wifiNetwork = network
            scheduleProbeSoon()
        }

        override fun onLost(network: Network) {
            if (wifiNetwork == network) wifiNetwork = null
            scheduleProbeSoon()
        }

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && isUsable(caps)) {
                wifiNetwork = network
            }
        }
    }

    private val cellCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            cellNetwork = network
            scheduleProbeSoon()
        }

        override fun onLost(network: Network) {
            if (cellNetwork == network) cellNetwork = null
            scheduleProbeSoon()
        }

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) && isUsable(caps)) {
                cellNetwork = network
            }
        }
    }

    fun start() {
        refreshNetworks()

        val wifiRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cellRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()

        try { cm.registerNetworkCallback(wifiRequest, wifiCallback) } catch (_: Exception) {}
        try { cm.registerNetworkCallback(cellRequest, cellCallback) } catch (_: Exception) {}
        scheduleNextProbe(0)
    }

    fun stop() {
        probeTask?.cancel(true)
        try { cm.unregisterNetworkCallback(wifiCallback) } catch (_: Exception) {}
        try { cm.unregisterNetworkCallback(cellCallback) } catch (_: Exception) {}
        scheduler.shutdownNow()
    }

    fun currentRoute(): DnsRoute? = bestRoute
    fun aiSummary(): String = lastAiStatus
    fun powerSummary(): String = lastPowerStatus

    fun resolve(payload: ByteArray): DnsResolution? {
        val preferred = bestRoute
        val candidates = mutableListOf<Triple<Network, String, Provider>>()

        if (preferred?.network != null && preferred.protocol == "DoH") {
            providers.firstOrNull { it.name == preferred.serverName }?.let {
                candidates += Triple(preferred.network, preferred.networkLabel, it)
            }
        }

        refreshNetworks()
        wifiNetwork?.let { net -> providers.forEach { candidates += Triple(net, "Wi‑Fi", it) } }
        cellNetwork?.let { net -> providers.forEach { candidates += Triple(net, "Celular", it) } }

        val seen = HashSet<String>()
        for ((network, label, provider) in candidates.filter {
            seen.add("${it.first}|${it.third.name}")
        }.take(6)) {
            val address = runCatching { InetAddress.getByName(provider.ip) }.getOrNull() ?: continue
            val result = dohExchange(network, provider, payload, 1800)
            if (result == null) {
                ai.record(provider.name, label, null, false)
                continue
            }
            ai.record(provider.name, label, result.second, true)
            val route = DnsRoute(network, label, provider.name, address, result.second)
            updateFromLiveResolution(route)
            return DnsResolution(result.first, route, result.second)
        }

        // Failsafe: se DoH falhar, usa o DNS nativo da própria rede em vez de
        // deixar os aplicativos sem resolução de nomes.
        val nativeNetworks = buildList {
            wifiNetwork?.let { add(it to "Wi‑Fi") }
            cellNetwork?.let { add(it to "Celular") }
        }
        for ((network, label) in nativeNetworks) {
            val fallback = nativeDnsExchange(network, label, payload, 1500)
            if (fallback != null) {
                val (body, route) = fallback
                bestRoute = route
                val power = powerPolicy.current()
                lastPowerStatus = "${power.label} • ${power.batteryPct}%"
                lastAiStatus = "IA local: DoH indisponível • failsafe com DNS nativo em $label"
                onRouteChanged(route, lastAiStatus, lastPowerStatus)
                return DnsResolution(body, route, route.rttMs)
            }
        }
        return null
    }

    private fun updateFromLiveResolution(route: DnsRoute) {
        val old = bestRoute
        if (old == null || old.network == route.network || route.rttMs + 25.0 < old.rttMs) {
            bestRoute = route
            if (old?.serverName != route.serverName || old.networkLabel != route.networkLabel) {
                val power = powerPolicy.current()
                lastPowerStatus = "${power.label} • ${power.batteryPct}%"
                lastAiStatus = "IA local: ${route.serverName} em ${route.networkLabel} • resposta ${route.rttMs.roundToInt()} ms"
                onRouteChanged(route, lastAiStatus, lastPowerStatus)
            }
        }
    }

    private fun probeBestRoute() {
        refreshNetworks()
        val power = powerPolicy.current()
        lastPowerStatus = "${power.label} • ${power.batteryPct}%"
        val candidates = mutableListOf<Pair<Network, String>>()
        wifiNetwork?.let { candidates += it to "Wi‑Fi" }
        cellNetwork?.let { candidates += it to "Celular" }

        if (candidates.isEmpty()) {
            bestRoute = null
            lastAiStatus = "IA local: aguardando rede com Internet"
            onRouteChanged(null, lastAiStatus, lastPowerStatus)
            return
        }

        val query = DnsPacket.buildProbeQuery(Random.nextInt(0, 65536), "connectivitycheck.gstatic.com")
        val successful = mutableListOf<Triple<AiCandidate, Network, InetAddress>>()

        for ((network, label) in candidates) {
            for (provider in providers) {
                val address = runCatching { InetAddress.getByName(provider.ip) }.getOrNull() ?: continue
                val result = dohExchange(network, provider, query, 1400)
                if (result == null || !DnsPacket.responseMatchesQuery(query, result.first)) {
                    ai.record(provider.name, label, null, false)
                    continue
                }
                ai.record(provider.name, label, result.second, true)
                successful += Triple(
                    AiCandidate(provider.name, label, result.second, label == "Celular"),
                    network,
                    address
                )
            }
        }

        val choice = ai.choose(successful.map { it.first }, power)
        val chosen = choice?.let { c -> successful.firstOrNull { it.first.provider == c.provider && it.first.networkLabel == c.networkLabel } }
        val winner = if (choice != null && chosen != null) {
            DnsRoute(chosen.second, choice.networkLabel, choice.provider, chosen.third, chosen.first.rttMs)
        } else null

        val old = bestRoute
        bestRoute = winner
        lastAiStatus = ai.summary(choice, power)
        if (old?.serverName != winner?.serverName ||
            old?.networkLabel != winner?.networkLabel ||
            kotlin.math.abs((old?.rttMs ?: -1.0) - (winner?.rttMs ?: -1.0)) >= 12.0
        ) {
            onRouteChanged(winner, lastAiStatus, lastPowerStatus)
        } else {
            onRouteChanged(winner, lastAiStatus, lastPowerStatus)
        }
    }

    private fun refreshNetworks() {
        var wifi: Network? = null
        var cell: Network? = null
        for (network in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (!isUsable(caps)) continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = network
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) cell = network
        }
        wifiNetwork = wifi ?: wifiNetwork?.takeIf { isStillUsable(it, NetworkCapabilities.TRANSPORT_WIFI) }
        cellNetwork = cell ?: cellNetwork?.takeIf { isStillUsable(it, NetworkCapabilities.TRANSPORT_CELLULAR) }
    }

    private fun isStillUsable(network: Network, transport: Int): Boolean {
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return isUsable(caps) && caps.hasTransport(transport)
    }

    private fun isUsable(caps: NetworkCapabilities): Boolean =
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)

    private fun scheduleNextProbe(delaySeconds: Long? = null) {
        if (scheduler.isShutdown) return
        probeTask?.cancel(false)
        val delay = delaySeconds ?: powerPolicy.current().probeIntervalSeconds
        probeTask = scheduler.schedule({
            try { probeBestRoute() } catch (_: Exception) {}
            scheduleNextProbe()
        }, delay, TimeUnit.SECONDS)
    }

    private fun scheduleProbeSoon() {
        if (scheduler.isShutdown) return
        scheduleNextProbe(1)
    }

    private fun nativeDnsExchange(
        network: Network,
        label: String,
        payload: ByteArray,
        timeoutMs: Int
    ): Pair<ByteArray, DnsRoute>? {
        val dnsServers = cm.getLinkProperties(network)?.dnsServers.orEmpty()
        for (server in dnsServers) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket(null)
                service.protect(socket)
                network.bindSocket(socket)
                socket.soTimeout = timeoutMs
                socket.bind(InetSocketAddress(0))
                val start = System.nanoTime()
                socket.send(DatagramPacket(payload, payload.size, server, 53))
                val response = ByteArray(65535)
                val packet = DatagramPacket(response, response.size)
                socket.receive(packet)
                val elapsed = (System.nanoTime() - start) / 1_000_000.0
                val body = response.copyOf(packet.length)
                if (!DnsPacket.responseMatchesQuery(payload, body)) continue
                val route = DnsRoute(network, label, "DNS nativo", server, elapsed, "Sistema")
                return body to route
            } catch (_: Exception) {
                // tenta o próximo servidor nativo
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        return null
    }

    /**
     * DNS-over-HTTPS sem DNS de bootstrap: conecta direto ao IP conhecido do provedor,
     * usa TLS com SNI/hostname e envia RFC 8484. O socket é explicitamente protegido
     * contra o próprio VPN para evitar loop de roteamento.
     */
    private fun dohExchange(
        network: Network,
        provider: Provider,
        payload: ByteArray,
        timeoutMs: Int
    ): Pair<ByteArray, Double>? {
        var raw: java.net.Socket? = null
        var tls: SSLSocket? = null
        return try {
            raw = network.socketFactory.createSocket()
            service.protect(raw)
            raw.connect(InetSocketAddress(provider.ip, 443), timeoutMs)
            raw.soTimeout = timeoutMs

            val sslFactory = HttpsURLConnection.getDefaultSSLSocketFactory() as SSLSocketFactory
            tls = sslFactory.createSocket(raw, provider.host, 443, true) as SSLSocket
            tls.soTimeout = timeoutMs
            tls.startHandshake()
            if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(provider.host, tls.session)) return null

            val requestHeaders = buildString {
                append("POST ${provider.path} HTTP/1.1\r\n")
                append("Host: ${provider.host}\r\n")
                append("Accept: application/dns-message\r\n")
                append("Content-Type: application/dns-message\r\n")
                append("Content-Length: ${payload.size}\r\n")
                append("Connection: close\r\n")
                append("User-Agent: NexaNetworkAI/0.8\r\n")
                append("\r\n")
            }.toByteArray(Charsets.US_ASCII)

            val start = System.nanoTime()
            tls.outputStream.write(requestHeaders)
            tls.outputStream.write(payload)
            tls.outputStream.flush()

            val all = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while (true) {
                val count = try { tls.inputStream.read(buffer) } catch (_: java.net.SocketTimeoutException) { -1 }
                if (count <= 0) break
                all.write(buffer, 0, count)
                if (all.size() > 131072) return null
            }
            val elapsed = (System.nanoTime() - start) / 1_000_000.0
            val rawResponse = all.toByteArray()
            val split = findHeaderEnd(rawResponse)
            if (split < 0) return null

            val headers = String(rawResponse, 0, split, Charsets.ISO_8859_1)
            val statusLine = headers.lineSequence().firstOrNull().orEmpty()
            if (!statusLine.contains(" 200 ")) return null

            val bodyRaw = rawResponse.copyOfRange(split + 4, rawResponse.size)
            val body = if (headers.contains("transfer-encoding: chunked", ignoreCase = true)) {
                decodeChunked(bodyRaw) ?: return null
            } else bodyRaw
            if (!DnsPacket.responseMatchesQuery(payload, body)) return null
            body to elapsed
        } catch (_: Exception) {
            null
        } finally {
            try { tls?.close() } catch (_: Exception) {}
            try { raw?.close() } catch (_: Exception) {}
        }
    }

    private fun findHeaderEnd(bytes: ByteArray): Int {
        for (i in 0 until bytes.size - 3) {
            if (bytes[i] == 13.toByte() && bytes[i + 1] == 10.toByte() &&
                bytes[i + 2] == 13.toByte() && bytes[i + 3] == 10.toByte()) return i
        }
        return -1
    }

    private fun decodeChunked(data: ByteArray): ByteArray? {
        var pos = 0
        val out = ByteArrayOutputStream()
        while (pos < data.size) {
            val lineEnd = findCrlf(data, pos) ?: return null
            val sizeText = String(data, pos, lineEnd - pos, Charsets.US_ASCII).substringBefore(';').trim()
            val size = sizeText.toIntOrNull(16) ?: return null
            pos = lineEnd + 2
            if (size == 0) return out.toByteArray()
            if (pos + size > data.size) return null
            out.write(data, pos, size)
            pos += size
            if (pos + 1 >= data.size || data[pos] != 13.toByte() || data[pos + 1] != 10.toByte()) return null
            pos += 2
        }
        return out.toByteArray()
    }

    private fun findCrlf(data: ByteArray, start: Int): Int? {
        for (i in start until data.size - 1) {
            if (data[i] == 13.toByte() && data[i + 1] == 10.toByte()) return i
        }
        return null
    }

    companion object {
        fun routeLabel(route: DnsRoute?): String {
            if (route == null) return "Procurando melhor DNS…"
            return "${route.serverName} ${route.protocol} • ${route.networkLabel} • ${route.rttMs.roundToInt()} ms"
        }
    }
}
