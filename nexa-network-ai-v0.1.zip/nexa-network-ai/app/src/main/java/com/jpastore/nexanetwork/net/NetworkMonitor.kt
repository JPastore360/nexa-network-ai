package com.jpastore.nexanetwork.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.jpastore.nexanetwork.power.PowerPolicy
import java.net.InetSocketAddress
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

class NetworkMonitor(
    context: Context,
    private val listener: (NetworkSnapshot) -> Unit
) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val radio = RadioInspector(context)
    private val powerPolicy = PowerPolicy(context)
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    @Volatile private var wifiNetwork: Network? = null
    @Volatile private var cellNetwork: Network? = null

    private val wifiHistory = SampleHistory()
    private val cellHistory = SampleHistory()
    private val probeIndex = AtomicInteger(0)
    private val probeTargets = arrayOf(
        "1.1.1.1" to 443,
        "8.8.8.8" to 443,
        "9.9.9.9" to 443
    )

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { wifiNetwork = network; scheduleImmediate() }
        override fun onLost(network: Network) { if (wifiNetwork == network) wifiNetwork = null; scheduleImmediate() }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && isUsable(caps)) wifiNetwork = network
        }
    }
    private val cellCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { cellNetwork = network; scheduleImmediate() }
        override fun onLost(network: Network) { if (cellNetwork == network) cellNetwork = null; scheduleImmediate() }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) && isUsable(caps)) cellNetwork = network
        }
    }

    fun start() {
        radio.start()
        refreshNetworks()
        val wifiRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cellRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()

        // Monitoramento passivo: não força Wi‑Fi ou 4G/5G a ficarem acordados.
        try { cm.registerNetworkCallback(wifiRequest, wifiCallback) } catch (_: Exception) {}
        try { cm.registerNetworkCallback(cellRequest, cellCallback) } catch (_: Exception) {}
        scheduleNext(0)
    }

    fun stop() {
        task?.cancel(true)
        try { cm.unregisterNetworkCallback(wifiCallback) } catch (_: Exception) {}
        try { cm.unregisterNetworkCallback(cellCallback) } catch (_: Exception) {}
        radio.stop()
        scheduler.shutdownNow()
    }

    private fun scheduleNext(delaySeconds: Long? = null) {
        if (scheduler.isShutdown) return
        task?.cancel(false)
        val delay = delaySeconds ?: powerPolicy.current().monitorIntervalSeconds
        task = scheduler.schedule({
            try {
                refreshNetworks()
                measureAll()
            } catch (_: Exception) {}
            scheduleNext()
        }, delay, TimeUnit.SECONDS)
    }

    private fun scheduleImmediate() {
        if (!scheduler.isShutdown) scheduleNext(1)
    }

    private fun refreshNetworks() {
        var wifi: Network? = null
        var cell: Network? = null
        for (network in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (!isUsable(caps)) continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = network
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) cell = network
        }
        wifiNetwork = wifi ?: wifiNetwork?.takeIf { isStillUsable(it, NetworkCapabilities.TRANSPORT_WIFI) }
        cellNetwork = cell ?: cellNetwork?.takeIf { isStillUsable(it, NetworkCapabilities.TRANSPORT_CELLULAR) }
    }

    private fun isStillUsable(network: Network, transport: Int): Boolean {
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return isUsable(caps) && caps.hasTransport(transport)
    }

    private fun isUsable(caps: NetworkCapabilities): Boolean =
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)

    private fun measureAll() {
        val wifi = measure(wifiNetwork, wifiHistory, "Wi‑Fi")
        val gen = radio.generation()
        val (dbm, radioDetail) = radio.detailedSignal()
        val cell = measure(cellNetwork, cellHistory, gen).copy(signalDbm = dbm, detail = radioDetail)
        val power = powerPolicy.current()

        val recommendation = when {
            wifi.available && cell.available -> {
                val ws = wifi.score()
                val cs = cell.score()
                when {
                    cs > ws + 10 -> "$gen responde melhor agora • score $cs vs Wi‑Fi $ws"
                    ws > cs + 10 -> "Wi‑Fi responde melhor agora • score $ws vs $gen $cs"
                    else -> "Redes próximas • IA prioriza estabilidade e bateria"
                }
            }
            wifi.available -> "Wi‑Fi ativo • celular não é mantido acordado à força"
            cell.available -> "$gen ativo • monitoramento passivo de baixo consumo"
            else -> "Aguardando rede com acesso à Internet"
        } + " • ${power.label}"

        listener(NetworkSnapshot(wifi, cell, gen, radioDetail, recommendation))
    }

    private fun measure(network: Network?, history: SampleHistory, label: String): PathMetrics {
        if (network == null) {
            history.add(null)
            return PathMetrics(available = false, label = label)
        }
        val latency = tcpConnectLatency(network)
        history.add(latency)
        return PathMetrics(
            network = network,
            available = latency != null,
            label = label,
            latencyMs = history.average(),
            jitterMs = history.jitter(),
            lossPct = history.lossPct()
        )
    }

    private fun tcpConnectLatency(network: Network): Double? {
        val socket = try { network.socketFactory.createSocket() } catch (_: Exception) { return null }
        return try {
            val target = probeTargets[Math.floorMod(probeIndex.getAndIncrement(), probeTargets.size)]
            val start = System.nanoTime()
            socket.connect(InetSocketAddress(target.first, target.second), 1200)
            (System.nanoTime() - start) / 1_000_000.0
        } catch (_: Exception) {
            null
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private class SampleHistory {
        private val samples = ArrayDeque<Double?>()
        fun add(value: Double?) {
            samples.addLast(value)
            while (samples.size > 8) samples.removeFirst()
        }
        fun average(): Double? {
            val ok = samples.filterNotNull()
            return if (ok.isEmpty()) null else ok.average()
        }
        fun jitter(): Double? {
            val ok = samples.filterNotNull()
            if (ok.size < 2) return null
            return ok.zipWithNext { a, b -> abs(a - b) }.average()
        }
        fun lossPct(): Double? {
            if (samples.isEmpty()) return null
            return samples.count { it == null }.toDouble() / samples.size.toDouble() * 100.0
        }
    }
}
