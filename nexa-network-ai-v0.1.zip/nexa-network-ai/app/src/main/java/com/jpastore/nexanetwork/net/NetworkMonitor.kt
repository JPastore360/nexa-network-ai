package com.jpastore.nexanetwork.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import java.net.InetSocketAddress
import java.net.Socket
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class NetworkMonitor(
    context: Context,
    private val listener: (NetworkSnapshot) -> Unit
) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val radio = RadioInspector(context)
    private val scheduler = Executors.newScheduledThreadPool(2)
    private var task: ScheduledFuture<*>? = null
    @Volatile private var wifiNetwork: Network? = null
    @Volatile private var cellNetwork: Network? = null

    private val wifiHistory = SampleHistory()
    private val cellHistory = SampleHistory()

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { wifiNetwork = network }
        override fun onLost(network: Network) { if (wifiNetwork == network) wifiNetwork = null }
    }
    private val cellCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { cellNetwork = network }
        override fun onLost(network: Network) { if (cellNetwork == network) cellNetwork = null }
    }

    fun start() {
        radio.start()
        val wifiRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cellRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        try { cm.requestNetwork(wifiRequest, wifiCallback) } catch (_: Exception) {}
        try { cm.requestNetwork(cellRequest, cellCallback) } catch (_: Exception) {}
        task = scheduler.scheduleWithFixedDelay({ measureAll() }, 0, 5, TimeUnit.SECONDS)
    }

    fun stop() {
        task?.cancel(true)
        try { cm.unregisterNetworkCallback(wifiCallback) } catch (_: Exception) {}
        try { cm.unregisterNetworkCallback(cellCallback) } catch (_: Exception) {}
        radio.stop()
        scheduler.shutdownNow()
    }

    private fun measureAll() {
        val wifi = measure(wifiNetwork, wifiHistory, "Wi‑Fi")
        val gen = radio.generation()
        val (dbm, radioDetail) = radio.detailedSignal()
        val cell = measure(cellNetwork, cellHistory, gen).copy(signalDbm = dbm, detail = radioDetail)

        val recommendation = when {
            wifi.available && cell.available -> {
                val ws = wifi.score()
                val cs = cell.score()
                if (cs > ws + 6) "$gen recomendado agora • score $cs vs Wi‑Fi $ws"
                else if (ws > cs + 6) "Wi‑Fi recomendado agora • score $ws vs $gen $cs"
                else "Smart Multipath recomendado • redes com qualidade semelhante"
            }
            wifi.available -> "Usando Wi‑Fi • celular indisponível"
            cell.available -> "Usando $gen • Wi‑Fi indisponível"
            else -> "Nenhuma rede com Internet detectada"
        }

        listener(NetworkSnapshot(wifi, cell, gen, radioDetail, recommendation))
    }

    private fun measure(network: Network?, history: SampleHistory, label: String): PathMetrics {
        if (network == null) {
            history.add(null)
            return PathMetrics(available = false, label = label)
        }
        val latency = tcpConnectLatency(network)
        history.add(latency)
        return PathMetrics(
            network = network,
            available = true,
            label = label,
            latencyMs = history.average(),
            jitterMs = history.jitter(),
            lossPct = history.lossPct()
        )
    }

    private fun tcpConnectLatency(network: Network): Double? {
        val socket = Socket()
        return try {
            network.bindSocket(socket)
            val start = System.nanoTime()
            socket.connect(InetSocketAddress("1.1.1.1", 443), 1800)
            (System.nanoTime() - start) / 1_000_000.0
        } catch (_: Exception) {
            null
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private class SampleHistory {
        private val samples = ArrayDeque<Double?>()
        fun add(value: Double?) {
            samples.addLast(value)
            while (samples.size > 8) samples.removeFirst()
        }
        fun average(): Double? {
            val ok = samples.filterNotNull()
            return if (ok.isEmpty()) null else ok.average()
        }
        fun jitter(): Double? {
            val ok = samples.filterNotNull()
            if (ok.size < 2) return null
            val diffs = ok.zipWithNext { a, b -> abs(a - b) }
            return diffs.average()
        }
        fun lossPct(): Double? {
            if (samples.isEmpty()) return null
            return samples.count { it == null }.toDouble() / samples.size.toDouble() * 100.0
        }
    }
}
