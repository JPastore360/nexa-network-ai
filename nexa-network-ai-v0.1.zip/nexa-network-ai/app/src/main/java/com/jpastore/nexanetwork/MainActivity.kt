package com.jpastore.nexanetwork

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.jpastore.nexanetwork.net.NetworkMonitor
import com.jpastore.nexanetwork.net.NetworkSnapshot
import com.jpastore.nexanetwork.tunnel.NexaVpnService
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var monitor: NetworkMonitor
    private lateinit var wifiText: TextView
    private lateinit var cellText: TextView
    private lateinit var aiText: TextView
    private lateinit var vpnText: TextView
    private lateinit var statusDot: TextView
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var keyInput: EditText
    private val main = Handler(Looper.getMainLooper())
    private val vpnRequestCode = 900

    private val bg = Color.rgb(5, 10, 15)
    private val panel = Color.rgb(10, 22, 31)
    private val panel2 = Color.rgb(12, 27, 38)
    private val border = Color.rgb(21, 77, 101)
    private val cyan = Color.rgb(0, 200, 255)
    private val green = Color.rgb(37, 235, 125)
    private val muted = Color.rgb(145, 164, 184)
    private val red = Color.rgb(255, 74, 92)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        setContentView(buildUi())
        loadConfig()
        monitor = NetworkMonitor(this) { snapshot -> main.post { render(snapshot) } }
        monitor.start()
        main.post(statusTicker)
    }

    override fun onDestroy() {
        monitor.stop()
        main.removeCallbacks(statusTicker)
        super.onDestroy()
    }

    private val statusTicker = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE)
            val status = prefs.getString(NexaVpnService.KEY_STATUS, "Desativado").orEmpty()
            val active = status.contains("ativo", ignoreCase = true) ||
                status.contains("túnel", ignoreCase = true) ||
                status.contains("iniciando", ignoreCase = true)
            vpnText.text = if (active) {
                "SMART MULTIPATH\n$status"
            } else {
                "SMART MULTIPATH\n$status"
            }
            statusDot.text = if (active) "●  ATIVO" else "●  DESATIVADO"
            statusDot.setTextColor(if (active) green else muted)
            vpnText.background = rounded(if (active) Color.rgb(7, 42, 31) else panel, if (active) Color.rgb(18, 124, 82) else border, 24)
            main.postDelayed(this, 1200)
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(34))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_logo)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)).apply { rightMargin = dp(12) }
        })
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("NEXA", 29, true, Color.WHITE))
            addView(text("NETWORK AI", 17, true, cyan))
            addView(text("CONECTIVIDADE INTELIGENTE", 10, false, muted))
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(pill("v0.2", cyan, Color.rgb(4, 35, 48)))
        root.addView(header)
        root.addView(space(16))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(panel, border, 24)
        }
        val heroTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heroTop.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_status_color)
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) }
        })
        vpnText = text("SMART MULTIPATH\nDesativado", 18, true, Color.WHITE).apply {
            setPadding(0, dp(2), 0, dp(2))
        }
        heroTop.addView(vpnText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        statusDot = text("●  DESATIVADO", 12, true, muted)
        heroTop.addView(statusDot)
        hero.addView(heroTop)
        hero.addView(space(10))
        hero.addView(text("Wi‑Fi + 2G/3G/4G/5G • failover automático • decisão local", 12, false, muted))
        root.addView(hero)
        root.addView(space(14))

        root.addView(section("QUALIDADE DAS REDES", "Medições independentes em tempo real"))
        val networkRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wifiText = networkCard("Wi‑Fi", cyan)
        cellText = networkCard("Celular", green)
        networkRow.addView(wifiText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        networkRow.addView(cellText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) })
        root.addView(networkRow)
        root.addView(space(14))

        aiText = cardText("IA LOCAL / DECISÃO\nAguardando medições…", Color.rgb(8, 30, 31), Color.rgb(17, 98, 83))
        root.addView(aiText)
        root.addView(space(18))

        root.addView(section("SERVIDOR V3", "Necessário para o túnel multipath real"))
        val serverCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = rounded(panel2, border, 20)
        }
        hostInput = edit("IPv4 do servidor, ex.: 203.0.113.10")
        portInput = edit("Porta UDP").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        keyInput = edit("Chave secreta (mín. 12 caracteres)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        serverCard.addView(hostInput)
        serverCard.addView(space(6))
        serverCard.addView(portInput)
        serverCard.addView(space(6))
        serverCard.addView(keyInput)
        serverCard.addView(space(10))
        serverCard.addView(button("SALVAR CONFIGURAÇÃO", cyan) { saveConfig() })
        root.addView(serverCard)
        root.addView(space(14))

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(button("⚡ ATIVAR", green) { prepareVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { rightMargin = dp(6) })
        actionRow.addView(button("■ PARAR", red) { stopVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(6) })
        root.addView(actionRow)
        root.addView(space(16))

        root.addView(featureStrip())
        root.addView(space(16))
        root.addView(text(
            "Bonding por fluxos • failover automático • VPN criptografada • monitoramento 2G/3G/4G/5G/Wi‑Fi. " +
                "O ícone NEXA permanece na barra de notificações enquanto o túnel estiver ativo.",
            11, false, muted
        ))
        root.addView(space(12))
        root.addView(text("NEXA NETWORK AI • v0.2.0", 10, true, Color.rgb(85, 108, 125)))
        return scroll
    }

    private fun featureStrip(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "VPN\nSegura" to cyan,
            "BONDING\nPor fluxo" to green,
            "FAILOVER\nAutomático" to cyan,
            "IA LOCAL\nAtiva" to green
        ).forEachIndexed { index, item ->
            val card = text(item.first, 11, true, item.second).apply {
                gravity = Gravity.CENTER
                setPadding(dp(7), dp(12), dp(7), dp(12))
                background = rounded(panel, border, 16)
            }
            row.addView(card, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                if (index > 0) leftMargin = dp(4)
                if (index < 3) rightMargin = dp(4)
            })
        }
        return row
    }

    private fun render(s: NetworkSnapshot) {
        wifiText.text = buildString {
            append("Wi‑Fi\n")
            append(if (s.wifi.available) "● CONECTADO" else "○ INDISPONÍVEL")
            append("\n\nScore  ${s.wifi.score()}/100")
            append("\nPing   ${s.wifi.latencyMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nJitter ${s.wifi.jitterMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nPerda  ${s.wifi.lossPct?.let { fmt(it) + "%" } ?: "—"}")
        }
        cellText.text = buildString {
            append("Celular ${s.radioGeneration}\n")
            append(if (s.cellular.available) "● CONECTADO" else "○ INDISPONÍVEL")
            append("\n\nScore  ${s.cellular.score()}/100")
            append("\nPing   ${s.cellular.latencyMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nJitter ${s.cellular.jitterMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nPerda  ${s.cellular.lossPct?.let { fmt(it) + "%" } ?: "—"}")
            s.cellular.signalDbm?.let { append("\nSinal  $it dBm") }
        }
        aiText.text = buildString {
            append("IA LOCAL / DECISÃO\n")
            append(s.recommendation)
            if (s.radioDetail.isNotBlank() && !s.radioDetail.contains("indisponível", true)) {
                append("\n\n${s.radioDetail}")
            }
        }
    }

    private fun prepareVpn() {
        saveConfig()
        val prefs = getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE)
        val host = prefs.getString(NexaVpnService.KEY_HOST, "").orEmpty()
        val key = prefs.getString(NexaVpnService.KEY_SECRET, "").orEmpty()
        if (host.isBlank() || key.length < 12) {
            aiText.text = "IA LOCAL / DECISÃO\nConfigure o servidor e uma chave com pelo menos 12 caracteres."
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, vpnRequestCode) else startVpn()
    }

    @Deprecated("Legacy result API kept to support minSdk without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, NexaVpnService::class.java).setAction(NexaVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopVpn() {
        val intent = Intent(this, NexaVpnService::class.java).setAction(NexaVpnService.ACTION_STOP)
        startService(intent)
    }

    private fun saveConfig() {
        val port = portInput.text.toString().toIntOrNull() ?: 51888
        getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE).edit()
            .putString(NexaVpnService.KEY_HOST, hostInput.text.toString().trim())
            .putInt(NexaVpnService.KEY_PORT, port)
            .putString(NexaVpnService.KEY_SECRET, keyInput.text.toString())
            .apply()
    }

    private fun loadConfig() {
        val prefs = getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE)
        hostInput.setText(prefs.getString(NexaVpnService.KEY_HOST, ""))
        portInput.setText(prefs.getInt(NexaVpnService.KEY_PORT, 51888).toString())
        keyInput.setText(prefs.getString(NexaVpnService.KEY_SECRET, ""))
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 901)
    }

    private fun section(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, 0, 0, dp(8))
        addView(text(title, 15, true, Color.WHITE))
        addView(text(subtitle, 11, false, muted))
    }

    private fun networkCard(title: String, accent: Int): TextView = text("$title\nAguardando medição…", 13, false, Color.WHITE).apply {
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(panel2, accent, 20)
        minHeight = dp(172)
    }

    private fun cardText(initial: String, fill: Int = panel, stroke: Int = border): TextView = text(initial, 14, false, Color.WHITE).apply {
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(fill, stroke, 20)
    }

    private fun edit(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        textSize = 14f
        setHintTextColor(Color.rgb(96, 120, 139))
        setTextColor(Color.WHITE)
        setSingleLine(true)
        setPadding(dp(13), dp(12), dp(13), dp(12))
        background = rounded(Color.rgb(7, 17, 24), Color.rgb(36, 75, 95), 14)
    }

    private fun button(label: String, accent: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(if (accent == green) Color.rgb(0, 26, 13) else Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(accent, accent, 16)
        setOnClickListener { action() }
    }

    private fun pill(label: String, color: Int, fill: Int): TextView = text(label, 11, true, color).apply {
        gravity = Gravity.CENTER
        setPadding(dp(9), dp(5), dp(9), dp(5))
        background = rounded(fill, color, 14)
    }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun text(value: String, sp: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = sp.toFloat()
        setTextColor(color)
        gravity = Gravity.START
        includeFontPadding = false
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun space(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun fmt(v: Double): String = String.format(Locale.US, "%.1f", v)
}
