package com.jpastore.nexanetwork

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.jpastore.nexanetwork.net.NetworkMonitor
import com.jpastore.nexanetwork.net.NetworkSnapshot
import com.jpastore.nexanetwork.tunnel.NexaVpnService
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var monitor: NetworkMonitor
    private lateinit var wifiText: TextView
    private lateinit var cellText: TextView
    private lateinit var aiText: TextView
    private lateinit var vpnText: TextView
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var keyInput: EditText
    private val main = Handler(Looper.getMainLooper())
    private val vpnRequestCode = 900

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        setContentView(buildUi())
        loadConfig()
        monitor = NetworkMonitor(this) { snapshot -> main.post { render(snapshot) } }
        monitor.start()
        main.post(statusTicker)
    }

    override fun onDestroy() {
        monitor.stop()
        main.removeCallbacks(statusTicker)
        super.onDestroy()
    }

    private val statusTicker = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE)
            vpnText.text = "VPN / Multipath: ${prefs.getString(NexaVpnService.KEY_STATUS, "Desativado")}" 
            main.postDelayed(this, 1500)
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(30))
            setBackgroundColor(Color.rgb(11, 13, 16))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        root.addView(text("NEXA NETWORK AI", 27, true, Color.WHITE))
        root.addView(text("2G • 3G • 4G • 5G • Wi‑Fi", 14, false, Color.rgb(148, 163, 184)))
        root.addView(space(16))

        vpnText = cardText("VPN / Multipath: Desativado")
        root.addView(vpnText)
        root.addView(space(10))

        wifiText = cardText("Wi‑Fi\nAguardando medição…")
        cellText = cardText("Celular\nAguardando medição…")
        aiText = cardText("IA local\nAguardando dados…")
        root.addView(wifiText)
        root.addView(space(10))
        root.addView(cellText)
        root.addView(space(10))
        root.addView(aiText)
        root.addView(space(20))

        root.addView(text("SERVIDOR V3", 16, true, Color.WHITE))
        root.addView(text("Use o IPv4 público da VM. A chave deve ser igual no app e no servidor.", 12, false, Color.rgb(148, 163, 184)))
        hostInput = edit("IPv4 do servidor, ex.: 203.0.113.10")
        portInput = edit("Porta UDP").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        keyInput = edit("Chave secreta (mín. 12 caracteres)")
        root.addView(hostInput)
        root.addView(portInput)
        root.addView(keyInput)

        val save = button("SALVAR SERVIDOR") { saveConfig() }
        val start = button("🚀 ATIVAR SMART MULTIPATH") { prepareVpn() }
        val stop = button("PARAR") { stopVpn() }
        root.addView(save)
        root.addView(space(8))
        root.addView(start)
        root.addView(space(8))
        root.addView(stop)
        root.addView(space(18))

        root.addView(text(
            "Esta versão usa bonding por fluxos: conexões diferentes podem sair por Wi‑Fi e rede celular ao mesmo tempo. " +
                "Ela não promete somar a velocidade de um único download. IPv6 permanece fora do túnel nesta versão inicial.",
            12, false, Color.rgb(148, 163, 184)
        ))
        return scroll
    }

    private fun render(s: NetworkSnapshot) {
        wifiText.text = buildString {
            append("Wi‑Fi • score ${s.wifi.score()}/100\n")
            append(if (s.wifi.available) "Ativo" else "Indisponível")
            s.wifi.latencyMs?.let { append(" • ping ${fmt(it)} ms") }
            s.wifi.jitterMs?.let { append("\nJitter ${fmt(it)} ms") }
            s.wifi.lossPct?.let { append(" • perda ${fmt(it)}%") }
        }
        cellText.text = buildString {
            append("Celular ${s.radioGeneration} • score ${s.cellular.score()}/100\n")
            append(if (s.cellular.available) "Ativo" else "Indisponível")
            s.cellular.latencyMs?.let { append(" • ping ${fmt(it)} ms") }
            s.cellular.jitterMs?.let { append("\nJitter ${fmt(it)} ms") }
            s.cellular.lossPct?.let { append(" • perda ${fmt(it)}%") }
            s.cellular.signalDbm?.let { append("\nSinal $it dBm") }
            if (s.radioDetail.isNotBlank()) append("\n${s.radioDetail}")
        }
        aiText.text = "IA LOCAL / DECISÃO\n${s.recommendation}"
    }

    private fun prepareVpn() {
        saveConfig()
        val prefs = getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE)
        val host = prefs.getString(NexaVpnService.KEY_HOST, "").orEmpty()
        val key = prefs.getString(NexaVpnService.KEY_SECRET, "").orEmpty()
        if (host.isBlank() || key.length < 12) {
            aiText.text = "IA LOCAL / DECISÃO\nConfigure servidor e chave válida primeiro."
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, vpnRequestCode) else startVpn()
    }

    @Deprecated("Legacy result API kept to support minSdk without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, NexaVpnService::class.java).setAction(NexaVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopVpn() {
        val intent = Intent(this, NexaVpnService::class.java).setAction(NexaVpnService.ACTION_STOP)
        startService(intent)
    }

    private fun saveConfig() {
        val port = portInput.text.toString().toIntOrNull() ?: 51888
        getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE).edit()
            .putString(NexaVpnService.KEY_HOST, hostInput.text.toString().trim())
            .putInt(NexaVpnService.KEY_PORT, port)
            .putString(NexaVpnService.KEY_SECRET, keyInput.text.toString())
            .apply()
    }

    private fun loadConfig() {
        val prefs = getSharedPreferences(NexaVpnService.PREFS, MODE_PRIVATE)
        hostInput.setText(prefs.getString(NexaVpnService.KEY_HOST, ""))
        portInput.setText(prefs.getInt(NexaVpnService.KEY_PORT, 51888).toString())
        keyInput.setText(prefs.getString(NexaVpnService.KEY_SECRET, ""))
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 901)
    }

    private fun cardText(initial: String): TextView = text(initial, 15, false, Color.WHITE).apply {
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(20, 24, 31))
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.rgb(45, 55, 72))
        }
    }

    private fun edit(hint: String): EditText = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.rgb(100, 116, 139))
        setTextColor(Color.WHITE)
        setSingleLine(true)
        setPadding(dp(12), dp(12), dp(12), dp(12))
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun text(value: String, sp: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = sp.toFloat()
        setTextColor(color)
        gravity = Gravity.START
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun space(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun fmt(v: Double): String = String.format(Locale.US, "%.1f", v)
}
