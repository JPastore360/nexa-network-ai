package com.jpastore.nexanetwork

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.jpastore.nexanetwork.dns.NexaDnsVpnService
import com.jpastore.nexanetwork.net.NetworkMonitor
import com.jpastore.nexanetwork.net.NetworkSnapshot
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var monitor: NetworkMonitor
    private lateinit var wifiText: TextView
    private lateinit var cellText: TextView
    private lateinit var optimizerText: TextView
    private lateinit var vpnText: TextView
    private lateinit var statusDot: TextView
    private lateinit var aiText: TextView
    private lateinit var powerText: TextView
    private lateinit var compatText: TextView
    @Volatile private var lastRecommendation: String = "Aguardando medições"

    private val main = Handler(Looper.getMainLooper())
    private val vpnRequestCode = 900

    private val bg = Color.rgb(5, 10, 15)
    private val panel = Color.rgb(10, 22, 31)
    private val panel2 = Color.rgb(12, 27, 38)
    private val border = Color.rgb(21, 77, 101)
    private val cyan = Color.rgb(0, 200, 255)
    private val green = Color.rgb(37, 235, 125)
    private val muted = Color.rgb(145, 164, 184)
    private val red = Color.rgb(255, 74, 92)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        setContentView(buildUi())
        monitor = NetworkMonitor(this) { snapshot -> main.post { render(snapshot) } }
        monitor.start()
        main.post(statusTicker)
    }

    override fun onDestroy() {
        monitor.stop()
        main.removeCallbacks(statusTicker)
        super.onDestroy()
    }

    private val statusTicker = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(NexaDnsVpnService.PREFS, MODE_PRIVATE)
            val status = prefs.getString(NexaDnsVpnService.KEY_STATUS, "Desativado").orEmpty()
            val route = prefs.getString(NexaDnsVpnService.KEY_ROUTE, "Procurando melhor DNS…").orEmpty()
            val ai = prefs.getString(NexaDnsVpnService.KEY_AI, "IA local: aguardando ativação").orEmpty()
            val power = prefs.getString(NexaDnsVpnService.KEY_POWER, "Economia adaptativa").orEmpty()
            val compat = prefs.getString(NexaDnsVpnService.KEY_COMPAT, "Split DNS: pronto").orEmpty()
            val active = status.contains("ativa", ignoreCase = true) ||
                status.contains("iniciando", ignoreCase = true)

            vpnText.text = if (active) "OTIMIZAÇÃO DE NAVEGAÇÃO\n$status" else "OTIMIZAÇÃO DE NAVEGAÇÃO\nDesativada"
            statusDot.text = if (active) "●  LIGADO" else "●  DESLIGADO"
            statusDot.setTextColor(if (active) green else muted)
            vpnText.background = rounded(
                if (active) Color.rgb(7, 42, 31) else panel,
                if (active) Color.rgb(18, 124, 82) else border,
                24
            )

            optimizerText.text = buildString {
                append("DNS INTELIGENTE\n")
                append(if (active) route else "Cloudflare • Google • Quad9 • DoH + fallback nativo")
                append("\n")
                append(lastRecommendation)
            }
            aiText.text = "NEXA AI LOCAL\n$ai\nAprendizado fica somente neste aparelho."
            powerText.text = "BATERIA ADAPTATIVA\n$power\nTela apagada e bateria baixa reduzem automaticamente as medições."
            compatText.text = "COMPATIBILIDADE / FAILSAFE\n$compat\nSe o DNS otimizado falhar repetidamente, a VPN desliga e restaura a Internet normal."
            main.postDelayed(this, 1500)
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(34))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_logo)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)).apply { rightMargin = dp(12) }
        })
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("NEXA", 29, true, Color.WHITE))
            addView(text("NETWORK AI", 17, true, cyan))
            addView(text("OTIMIZADOR LOCAL DE NAVEGAÇÃO", 10, false, muted))
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(pill("v0.6", cyan, Color.rgb(4, 35, 48)))
        root.addView(header)
        root.addView(space(16))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(panel, border, 24)
        }
        val heroTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heroTop.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_status_color)
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) }
        })
        vpnText = text("OTIMIZAÇÃO DE NAVEGAÇÃO\nDesativada", 18, true, Color.WHITE)
        heroTop.addView(vpnText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        statusDot = text("●  DESLIGADO", 12, true, muted)
        heroTop.addView(statusDot)
        hero.addView(heroTop)
        hero.addView(space(10))
        hero.addView(text("Wi‑Fi • 2G • 3G • 4G • 5G  |  Split DNS + IA local + failsafe", 12, false, muted))
        root.addView(hero)
        root.addView(space(14))

        root.addView(section("QUALIDADE DAS REDES", "Ping, jitter, perda e score • monitoramento passivo"))
        val networkRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wifiText = networkCard("Wi‑Fi", cyan)
        cellText = networkCard("Celular", green)
        networkRow.addView(wifiText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        networkRow.addView(cellText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) })
        root.addView(networkRow)
        root.addView(space(14))

        optimizerText = cardText(
            "DNS INTELIGENTE\nCloudflare • Google • Quad9 • DoH + fallback nativo\nAguardando medições",
            Color.rgb(8, 30, 31),
            Color.rgb(17, 98, 83)
        )
        root.addView(optimizerText)
        root.addView(space(10))

        aiText = cardText(
            "NEXA AI LOCAL\nAprende latência e confiabilidade no aparelho.\nNenhuma IA em nuvem.",
            Color.rgb(8, 22, 34),
            Color.rgb(26, 83, 114)
        )
        root.addView(aiText)
        root.addView(space(10))

        powerText = cardText(
            "BATERIA ADAPTATIVA\nMedições aceleram quando necessário e desaceleram em segundo plano.",
            Color.rgb(24, 25, 18),
            Color.rgb(115, 110, 41)
        )
        root.addView(powerText)
        root.addView(space(10))

        compatText = cardText(
            "COMPATIBILIDADE / FAILSAFE\nSplit DNS pronto • ChatGPT e WhatsApp protegidos de interferência.",
            Color.rgb(27, 17, 24),
            Color.rgb(110, 55, 91)
        )
        root.addView(compatText)
        root.addView(space(16))

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(button("⚡ OTIMIZAR", green) { prepareVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { rightMargin = dp(6) })
        actionRow.addView(button("■ PARAR", red) { stopVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(6) })
        root.addView(actionRow)
        root.addView(space(16))

        root.addView(featureStrip())
        root.addView(space(16))
        root.addView(text(
            "PRIVACIDADE: zero analytics, zero telemetria e zero login. O Nexa envia somente as consultas DNS necessárias aos provedores escolhidos. " +
                "ChatGPT/WhatsApp podem usar a Internet diretamente para evitar incompatibilidades.",
            11,
            false,
            muted
        ))
        root.addView(space(12))
        root.addView(text("NEXA NETWORK AI • v0.6.0", 10, true, Color.rgb(85, 108, 125)))
        return scroll
    }

    private fun featureStrip(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "IA\nLocal" to cyan,
            "FAILSAFE\nAuto" to green,
            "BATERIA\nAdaptativa" to cyan,
            "ZERO\nTelemetria" to green
        ).forEachIndexed { index, item ->
            val card = text(item.first, 11, true, item.second).apply {
                gravity = Gravity.CENTER
                setPadding(dp(7), dp(12), dp(7), dp(12))
                background = rounded(panel, border, 16)
            }
            row.addView(card, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                if (index > 0) leftMargin = dp(4)
                if (index < 3) rightMargin = dp(4)
            })
        }
        return row
    }

    private fun render(s: NetworkSnapshot) {
        lastRecommendation = s.recommendation
        wifiText.text = buildString {
            append("Wi‑Fi\n")
            append(if (s.wifi.available) "● CONECTADO" else "○ INDISPONÍVEL")
            append("\n\nScore  ${s.wifi.score()}/100")
            append("\nPing   ${s.wifi.latencyMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nJitter ${s.wifi.jitterMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nPerda  ${s.wifi.lossPct?.let { fmt(it) + "%" } ?: "—"}")
        }
        cellText.text = buildString {
            append("Celular ${s.radioGeneration}\n")
            append(if (s.cellular.available) "● CONECTADO" else "○ EM ESPERA")
            append("\n\nScore  ${s.cellular.score()}/100")
            append("\nPing   ${s.cellular.latencyMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nJitter ${s.cellular.jitterMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nPerda  ${s.cellular.lossPct?.let { fmt(it) + "%" } ?: "—"}")
            s.cellular.signalDbm?.let { append("\nSinal  $it dBm") }
        }
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, vpnRequestCode) else startVpn()
    }

    @Deprecated("Legacy result API kept to support minSdk without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, NexaDnsVpnService::class.java).setAction(NexaDnsVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopVpn() {
        val intent = Intent(this, NexaDnsVpnService::class.java).setAction(NexaDnsVpnService.ACTION_STOP)
        startService(intent)
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 901)
    }

    private fun section(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, 0, 0, dp(8))
        addView(text(title, 15, true, Color.WHITE))
        addView(text(subtitle, 11, false, muted))
    }

    private fun networkCard(title: String, accent: Int): TextView = text("$title\nAguardando medição…", 13, false, Color.WHITE).apply {
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(panel2, accent, 20)
        minHeight = dp(172)
    }

    private fun cardText(initial: String, fill: Int = panel, stroke: Int = border): TextView = text(initial, 13, false, Color.WHITE).apply {
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(fill, stroke, 20)
    }

    private fun button(label: String, accent: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(if (accent == green) Color.rgb(0, 26, 13) else Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(accent, accent, 16)
        setOnClickListener { action() }
    }

    private fun pill(label: String, color: Int, fill: Int): TextView = text(label, 11, true, color).apply {
        gravity = Gravity.CENTER
        setPadding(dp(9), dp(5), dp(9), dp(5))
        background = rounded(fill, color, 14)
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun fmt(v: Double): String = String.format(Locale.US, "%.1f", v)
}
