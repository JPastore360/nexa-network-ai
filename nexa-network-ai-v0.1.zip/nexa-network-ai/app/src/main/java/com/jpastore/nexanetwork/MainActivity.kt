package com.jpastore.nexanetwork

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.jpastore.nexanetwork.dns.NexaDnsVpnService
import com.jpastore.nexanetwork.net.NetworkMonitor
import com.jpastore.nexanetwork.net.NetworkSnapshot
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var monitor: NetworkMonitor
    private lateinit var wifiText: TextView
    private lateinit var cellText: TextView
    private lateinit var optimizerText: TextView
    private lateinit var vpnText: TextView
    private lateinit var statusDot: TextView
    private lateinit var aiText: TextView
    private lateinit var decisionText: TextView
    private lateinit var signalText: TextView
    private lateinit var versionPill: TextView

    @Volatile private var lastRecommendation: String = "Aguardando medições"
    @Volatile private var lastSnapshot: NetworkSnapshot? = null
    @Volatile private var lastRoute: String = "Procurando melhor DNS…"
    @Volatile private var lastAi: String = "IA local: aguardando ativação"
    @Volatile private var lastPower: String = "Economia adaptativa"
    @Volatile private var lastCompat: String = "Split DNS: pronto"
    @Volatile private var lastStatus: String = "Desativado"

    private val main = Handler(Looper.getMainLooper())
    private val vpnRequestCode = 900

    private val bg = Color.rgb(5, 10, 15)
    private val panel = Color.rgb(10, 22, 31)
    private val panel2 = Color.rgb(12, 27, 38)
    private val border = Color.rgb(21, 77, 101)
    private val cyan = Color.rgb(0, 200, 255)
    private val green = Color.rgb(37, 235, 125)
    private val amber = Color.rgb(245, 196, 66)
    private val muted = Color.rgb(145, 164, 184)
    private val red = Color.rgb(255, 74, 92)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        setContentView(buildUi())
        monitor = NetworkMonitor(this) { snapshot -> main.post { render(snapshot) } }
        monitor.start()
        main.post(statusTicker)
    }

    override fun onDestroy() {
        monitor.stop()
        main.removeCallbacks(statusTicker)
        super.onDestroy()
    }

    private val statusTicker = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(NexaDnsVpnService.PREFS, MODE_PRIVATE)
            lastStatus = prefs.getString(NexaDnsVpnService.KEY_STATUS, "Desativado").orEmpty()
            lastRoute = prefs.getString(NexaDnsVpnService.KEY_ROUTE, "Procurando melhor DNS…").orEmpty()
            lastAi = prefs.getString(NexaDnsVpnService.KEY_AI, "IA local: aguardando ativação").orEmpty()
            lastPower = prefs.getString(NexaDnsVpnService.KEY_POWER, "Economia adaptativa").orEmpty()
            lastCompat = prefs.getString(NexaDnsVpnService.KEY_COMPAT, "Split DNS: pronto").orEmpty()

            val active = lastStatus.contains("ativa", ignoreCase = true) ||
                lastStatus.contains("iniciando", ignoreCase = true) ||
                lastStatus.contains("selecionando", ignoreCase = true)

            vpnText.text = if (active) "NEXA AI ATIVO\n$lastStatus" else "NEXA AI\nToque em otimizar para iniciar"
            statusDot.text = if (active) "●  LIGADO" else "●  DESLIGADO"
            statusDot.setTextColor(if (active) green else muted)
            vpnText.background = rounded(
                if (active) Color.rgb(7, 42, 31) else panel,
                if (active) Color.rgb(18, 124, 82) else border,
                24
            )

            optimizerText.text = buildString {
                append("DNS / ROTA ATUAL\n")
                append(if (active) lastRoute else "Cloudflare • Google • Quad9 • DoH")
                append("\n")
                append(if (active) "Failsafe pronto" else "Pronto para analisar")
            }
            aiText.text = buildString {
                append("NEXA AI\n")
                append(lastAi.substringBefore("\n"))
                append("\n")
                append(lastRecommendation)
            }
            main.postDelayed(this, 1500)
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(34))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_logo)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)).apply { rightMargin = dp(12) }
        })
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("NEXA", 29, true, Color.WHITE))
            addView(text("NETWORK AI", 17, true, cyan))
            addView(text("OTIMIZADOR LOCAL DE NAVEGAÇÃO", 10, false, muted))
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        versionPill = pill("v${appVersion()}", cyan, Color.rgb(4, 35, 48))
        header.addView(versionPill)
        root.addView(header)
        root.addView(space(16))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(panel, border, 24)
        }
        val heroTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heroTop.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_status_color)
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) }
        })
        vpnText = text("NEXA AI\nToque em otimizar para iniciar", 17, true, Color.WHITE)
        heroTop.addView(vpnText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        statusDot = text("●  DESLIGADO", 12, true, muted)
        heroTop.addView(statusDot)
        hero.addView(heroTop)
        hero.addView(space(10))
        hero.addView(text("Wi‑Fi • 2G • 3G • 4G • 5G  |  DNS inteligente + IA local", 12, false, muted))
        root.addView(hero)
        root.addView(space(14))

        decisionText = cardText(
            "MELHOR ESCOLHA AGORA\nAguardando medições das redes…",
            Color.rgb(8, 30, 31),
            Color.rgb(17, 98, 83)
        )
        root.addView(decisionText)
        root.addView(space(14))

        root.addView(section("QUALIDADE DAS REDES", "Dados reais e atualizados localmente"))
        val networkRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wifiText = networkCard("Wi‑Fi", cyan)
        cellText = networkCard("Celular", green)
        networkRow.addView(wifiText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        networkRow.addView(cellText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(6) })
        root.addView(networkRow)
        root.addView(space(12))

        signalText = cardText(
            "SINAL CELULAR\nAguardando leitura do modem…",
            Color.rgb(21, 22, 18),
            Color.rgb(112, 104, 43)
        ).apply { setOnClickListener { showSignalDialog() } }
        root.addView(signalText)
        root.addView(space(12))

        optimizerText = cardText(
            "DNS / ROTA ATUAL\nCloudflare • Google • Quad9 • DoH\nPronto para analisar",
            Color.rgb(8, 30, 31),
            Color.rgb(17, 98, 83)
        )
        root.addView(optimizerText)
        root.addView(space(10))

        aiText = cardText(
            "NEXA AI\nAprendizado local de latência e estabilidade.\nNenhuma IA em nuvem.",
            Color.rgb(8, 22, 34),
            Color.rgb(26, 83, 114)
        )
        root.addView(aiText)
        root.addView(space(16))

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(button("⚡ OTIMIZAR", green) { prepareVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { rightMargin = dp(6) })
        actionRow.addView(button("■ PARAR", red) { stopVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { leftMargin = dp(6) })
        root.addView(actionRow)
        root.addView(space(16))

        root.addView(section("FERRAMENTAS", "Agora todos os atalhos abaixo têm função"))
        root.addView(featureGrid())
        root.addView(space(16))

        root.addView(text(
            "PRIVACIDADE: zero analytics, zero telemetria e zero login. Métricas e aprendizado permanecem neste aparelho. " +
                "O Nexa não aumenta a potência física da antena; ele mede a qualidade real e evita rotas ruins.",
            11,
            false,
            muted
        ))
        root.addView(space(12))
        root.addView(text("NEXA NETWORK AI • v${appVersion()}", 10, true, Color.rgb(85, 108, 125)))
        return scroll
    }

    private fun featureGrid(): View {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        row1.addView(featureButton("IA\nDecisões", cyan) { showAiDialog() }, weighted(0, 5))
        row1.addView(featureButton("DIAGNÓSTICO\nRede", green) { showDiagnosticDialog() }, weighted(5, 0))
        row2.addView(featureButton("BATERIA\nAdaptativa", amber) { showBatteryDialog() }, weighted(0, 5))
        row2.addView(featureButton("PRIVACIDADE\nLocal", cyan) { showPrivacyDialog() }, weighted(5, 0))

        outer.addView(row1)
        outer.addView(space(10))
        outer.addView(row2)
        return outer
    }

    private fun weighted(left: Int, right: Int) = LinearLayout.LayoutParams(0, dp(68), 1f).apply {
        leftMargin = dp(left)
        rightMargin = dp(right)
    }

    private fun featureButton(label: String, accent: Int, action: () -> Unit): TextView = text(label, 12, true, accent).apply {
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(10), dp(8), dp(10))
        background = rounded(panel, border, 16)
        setOnClickListener { action() }
    }

    private fun render(s: NetworkSnapshot) {
        lastSnapshot = s
        lastRecommendation = s.recommendation

        wifiText.text = buildString {
            append("Wi‑Fi\n")
            append(if (s.wifi.available) "● CONECTADO" else "○ INDISPONÍVEL")
            append("\n\nScore  ${s.wifi.score()}/100")
            append("\nPing   ${s.wifi.latencyMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nJitter ${s.wifi.jitterMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nPerda  ${s.wifi.lossPct?.let { fmt(it) + "%" } ?: "—"}")
        }
        cellText.text = buildString {
            append("Celular ${s.radioGeneration}\n")
            append(if (s.cellular.available) "● CONECTADO" else "○ EM ESPERA")
            append("\n\nScore  ${s.cellular.score()}/100")
            append("\nPing   ${s.cellular.latencyMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nJitter ${s.cellular.jitterMs?.let { fmt(it) + " ms" } ?: "—"}")
            append("\nPerda  ${s.cellular.lossPct?.let { fmt(it) + "%" } ?: "—"}")
            s.cellular.signalDbm?.let { append("\nSinal  $it dBm") }
        }

        decisionText.text = decisionSummary(s)
        val dbm = s.cellular.signalDbm
        signalText.text = buildString {
            append("SINAL CELULAR • toque para detalhes\n")
            if (dbm != null) {
                append("${s.radioGeneration} • $dbm dBm • ${signalQuality(dbm)}")
            } else {
                append("${s.radioGeneration} • métrica detalhada indisponível")
            }
            append("\nO Nexa monitora o rádio; não amplifica fisicamente a antena.")
        }
    }

    private fun decisionSummary(s: NetworkSnapshot): String {
        val ws = s.wifi.score()
        val cs = s.cellular.score()
        return when {
            s.wifi.available && s.cellular.available && ws > cs -> {
                val delta = ws - cs
                "MELHOR ESCOLHA AGORA\nWi‑Fi • score $ws/100 • +$delta pontos sobre ${s.radioGeneration}\n${s.wifi.latencyMs?.let { "Ping ${fmt(it)} ms" } ?: "Rede estável"}"
            }
            s.wifi.available && s.cellular.available && cs > ws -> {
                val delta = cs - ws
                "MELHOR ESCOLHA AGORA\n${s.radioGeneration} • score $cs/100 • +$delta pontos sobre Wi‑Fi\n${s.cellular.latencyMs?.let { "Ping ${fmt(it)} ms" } ?: "Rede estável"}"
            }
            s.wifi.available && s.cellular.available -> "MELHOR ESCOLHA AGORA\nRedes equilibradas • IA prioriza estabilidade e bateria"
            s.wifi.available -> "MELHOR ESCOLHA AGORA\nWi‑Fi ativo • score $ws/100"
            s.cellular.available -> "MELHOR ESCOLHA AGORA\n${s.radioGeneration} ativo • score $cs/100"
            else -> "MELHOR ESCOLHA AGORA\nAguardando rede com acesso à Internet…"
        }
    }

    private fun showAiDialog() {
        showDialog(
            "Nexa AI • decisões locais",
            "$lastAi\n\nRede: $lastRecommendation\n\nA IA usa latência, jitter, perda, estabilidade e bateria. Nada é enviado para uma IA na nuvem."
        )
    }

    private fun showDiagnosticDialog() {
        val s = lastSnapshot
        val body = if (s == null) {
            "Ainda não há amostras suficientes. Aguarde alguns segundos com a tela aberta."
        } else buildString {
            append("Internet / VPN: $lastStatus\n")
            append("DNS: $lastRoute\n\n")
            append("Wi‑Fi: ${if (s.wifi.available) "OK" else "indisponível"} • score ${s.wifi.score()}/100\n")
            append("${s.radioGeneration}: ${if (s.cellular.available) "OK" else "em espera"} • score ${s.cellular.score()}/100\n")
            append("Sinal: ${s.cellular.signalDbm?.let { "$it dBm • ${signalQuality(it)}" } ?: "não disponível"}\n\n")
            append("Failsafe: $lastCompat")
        }
        showDialog("Diagnóstico de rede", body)
    }

    private fun showSignalDialog() {
        val s = lastSnapshot
        val dbm = s?.cellular?.signalDbm
        val detail = s?.radioDetail?.takeIf { it.isNotBlank() } ?: "Métrica detalhada indisponível neste momento."
        val body = buildString {
            append("Tecnologia: ${s?.radioGeneration ?: "—"}\n")
            append("Potência: ${dbm?.let { "$it dBm" } ?: "—"}\n")
            append("Qualidade aproximada: ${dbm?.let { signalQuality(it) } ?: "—"}\n\n")
            append(detail)
            append("\n\nImportante: o Nexa não aumenta a potência da torre nem da antena. O Android/modem escolhe a célula e a banda. O app consegue medir, comparar e evitar usar uma rota ruim, mas não criar sinal de rádio onde ele não existe.")
        }
        showDialog("Assistente de sinal", body)
    }

    private fun showBatteryDialog() {
        showDialog(
            "Bateria adaptativa",
            "$lastPower\n\nCom a tela apagada ou bateria baixa, o Nexa reduz a frequência das medições. Ele também evita manter 4G/5G acordado apenas para testar quando não é necessário."
        )
    }

    private fun showPrivacyDialog() {
        showDialog(
            "Privacidade",
            "• Zero analytics\n• Zero telemetria\n• Zero login\n• Aprendizado somente local\n• Sem histórico de navegação\n• Sem IA em nuvem\n\nAs consultas DNS necessárias são enviadas ao provedor selecionado (Cloudflare, Google ou Quad9), que inevitavelmente vê o IP público da conexão. O Nexa não envia suas métricas pessoais junto com essas consultas."
        )
    }

    private fun showDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun signalQuality(dbm: Int): String = when {
        dbm >= -85 -> "Excelente"
        dbm >= -95 -> "Bom"
        dbm >= -105 -> "Regular"
        dbm >= -115 -> "Fraco"
        else -> "Muito fraco"
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, vpnRequestCode) else startVpn()
    }

    @Deprecated("Legacy result API kept to support minSdk without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, NexaDnsVpnService::class.java).setAction(NexaDnsVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopVpn() {
        val intent = Intent(this, NexaDnsVpnService::class.java).setAction(NexaDnsVpnService.ACTION_STOP)
        startService(intent)
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 901)
    }

    @Suppress("DEPRECATION")
    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (_: Exception) {
        "?"
    }

    private fun section(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, 0, 0, dp(8))
        addView(text(title, 15, true, Color.WHITE))
        addView(text(subtitle, 11, false, muted))
    }

    private fun networkCard(title: String, accent: Int): TextView = text("$title\nAguardando medição…", 13, false, Color.WHITE).apply {
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = rounded(panel2, accent, 20)
        minHeight = dp(160)
    }

    private fun cardText(initial: String, fill: Int = panel, stroke: Int = border): TextView = text(initial, 13, false, Color.WHITE).apply {
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(fill, stroke, 20)
    }

    private fun button(label: String, accent: Int, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(if (accent == green) Color.rgb(0, 26, 13) else Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(accent, accent, 16)
        setOnClickListener { action() }
    }

    private fun pill(label: String, color: Int, fill: Int): TextView = text(label, 11, true, color).apply {
        gravity = Gravity.CENTER
        setPadding(dp(9), dp(5), dp(9), dp(5))
        background = rounded(fill, color, 14)
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun fmt(v: Double): String = String.format(Locale.US, "%.1f", v)
}
