package com.jpastore.nexanetwork

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.jpastore.nexanetwork.dns.NexaDnsVpnService
import com.jpastore.nexanetwork.net.NetworkMonitor
import com.jpastore.nexanetwork.net.NetworkSnapshot
import com.jpastore.nexanetwork.net.NetworkIntelligence
import java.util.Locale
import java.net.Inet4Address
import java.net.Inet6Address

class MainActivity : Activity() {
    private lateinit var monitor: NetworkMonitor
    private lateinit var contentHost: LinearLayout
    private lateinit var settingsStore: AppSettings
    private lateinit var historyStore: HistoryStore
    private lateinit var sessionStore: OptimizationSessionStore
    private val main = Handler(Looper.getMainLooper())
    private val vpnRequestCode = 900

    @Volatile private var lastRecommendation = "Aguardando medições"
    @Volatile private var lastSnapshot: NetworkSnapshot? = null
    @Volatile private var lastRoute = "Procurando melhor DNS…"
    @Volatile private var lastAi = "IA local: aguardando ativação"
    @Volatile private var lastPower = "Economia adaptativa"
    @Volatile private var lastCompat = "Split DNS: pronto"
    @Volatile private var lastStatus = "Desativado"
    @Volatile private var lastUpdatedAt = 0L
    private var currentTab = Tab.HOME

    private var wifiText: TextView? = null
    private var cellText: TextView? = null
    private var optimizerText: TextView? = null
    private var vpnText: TextView? = null
    private var statusDot: TextView? = null
    private var aiText: TextView? = null
    private var decisionText: TextView? = null
    private var signalText: TextView? = null
    private var congestionText: TextView? = null
    private var beforeAfterText: TextView? = null
    private var updatedText: TextView? = null

    private val bg = Color.rgb(5, 10, 15)
    private val panel = Color.rgb(10, 22, 31)
    private val panel2 = Color.rgb(12, 27, 38)
    private val border = Color.rgb(21, 77, 101)
    private val cyan = Color.rgb(0, 200, 255)
    private val green = Color.rgb(37, 235, 125)
    private val amber = Color.rgb(245, 196, 66)
    private val muted = Color.rgb(145, 164, 184)
    private val red = Color.rgb(255, 74, 92)

    private enum class Tab { HOME, AI, DIAGNOSTIC, HISTORY, SETTINGS }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        settingsStore = AppSettings(this)
        historyStore = HistoryStore(this)
        sessionStore = OptimizationSessionStore(this)
        requestRuntimePermissions()
        setContentView(buildShell())
        showTab(Tab.HOME)
        monitor = NetworkMonitor(this) { snapshot -> main.post { render(snapshot) } }
        monitor.start()
        main.post(statusTicker)
    }

    override fun onDestroy() {
        monitor.stop()
        main.removeCallbacks(statusTicker)
        super.onDestroy()
    }

    private fun buildShell(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        contentHost = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        outer.addView(contentHost, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        outer.addView(buildBottomNav())
        return outer
    }

    private fun buildBottomNav(): View {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(7), dp(6), dp(8))
            background = rounded(Color.rgb(6, 15, 22), Color.rgb(15, 48, 65), 0)
        }
        listOf(
            Triple(Tab.HOME, "⌂\nInício", cyan),
            Triple(Tab.AI, "AI\nIA", green),
            Triple(Tab.DIAGNOSTIC, "✓\nDiagnóstico", cyan),
            Triple(Tab.HISTORY, "↻\nHistórico", amber),
            Triple(Tab.SETTINGS, "⚙\nAjustes", muted)
        ).forEach { (tab, label, color) ->
            nav.addView(text(label, 10, true, color).apply {
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(5), dp(3), dp(5))
                setOnClickListener { showTab(tab) }
            }, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        return nav
    }

    private fun showTab(tab: Tab) {
        currentTab = tab
        clearHomeRefs()
        contentHost.removeAllViews()
        contentHost.addView(when (tab) {
            Tab.HOME -> buildHome()
            Tab.AI -> buildAiScreen()
            Tab.DIAGNOSTIC -> buildDiagnosticScreen()
            Tab.HISTORY -> buildHistoryScreen()
            Tab.SETTINGS -> buildSettingsScreen()
        })
        if (tab == Tab.HOME) {
            lastSnapshot?.let { render(it) }
            updateLiveTexts()
        }
    }

    private fun screenRoot(): Pair<ScrollView, LinearLayout> {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(bg)
        }
        return ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        } to root
    }

    private fun addHeader(root: LinearLayout, subtitle: String) {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_logo)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(10) }
        })
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("NEXA NETWORK AI", 21, true, Color.WHITE))
            addView(text(subtitle, 10, false, muted))
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(pill("v${appVersion()}", cyan, Color.rgb(4, 35, 48)))
        root.addView(header)
        root.addView(space(16))
    }

    private fun buildHome(): View {
        val (scroll, root) = screenRoot()
        addHeader(root, "OTIMIZADOR LOCAL DE CONECTIVIDADE")

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, border, 22)
        }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_nexa_status_color)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) }
        })
        vpnText = text("NEXA AI\nPronto para otimizar", 17, true, Color.WHITE)
        line.addView(vpnText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        statusDot = text("● DESLIGADO", 11, true, muted)
        line.addView(statusDot)
        hero.addView(line)
        hero.addView(space(8))
        hero.addView(text("Wi‑Fi • 2G • 3G • 4G • 5G  |  DNS inteligente + IA local", 11, false, muted))
        updatedText = text("Última análise: aguardando", 10, false, Color.rgb(103, 129, 148))
        hero.addView(updatedText)
        root.addView(hero)
        root.addView(space(12))

        decisionText = cardText("MELHOR ESCOLHA AGORA\nAguardando medições…", Color.rgb(8, 30, 31), Color.rgb(17, 98, 83))
        root.addView(decisionText)
        root.addView(space(12))

        root.addView(section("QUALIDADE DAS REDES", "Dados locais • ping, jitter, perda e score"))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wifiText = networkCard("Wi‑Fi", cyan)
        cellText = networkCard("Celular", green)
        row.addView(wifiText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(5) })
        row.addView(cellText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(5) })
        root.addView(row)
        root.addView(space(10))

        signalText = cardText("SINAL CELULAR\nAguardando leitura do modem…", Color.rgb(21, 22, 18), Color.rgb(112, 104, 43)).apply {
            setOnClickListener { showSignalDialog() }
        }
        root.addView(signalText)
        root.addView(space(10))

        congestionText = cardText("SAÚDE / CONGESTIONAMENTO\nAguardando amostras…", Color.rgb(27, 23, 12), Color.rgb(121, 93, 31))
        root.addView(congestionText)
        root.addView(space(10))

        beforeAfterText = cardText("ANTES × AGORA\nAtive o Nexa para registrar uma comparação real.", Color.rgb(11, 24, 34), Color.rgb(34, 91, 121))
        root.addView(beforeAfterText)
        root.addView(space(10))

        optimizerText = cardText("DNS / ROTA ATUAL\nCloudflare • Google • Quad9 • DoH\nPronto para analisar", Color.rgb(8, 30, 31), Color.rgb(17, 98, 83))
        root.addView(optimizerText)
        root.addView(space(10))

        aiText = cardText("NEXA AI\nAprendizado local ativo quando a otimização é iniciada.", Color.rgb(8, 22, 34), Color.rgb(26, 83, 114))
        root.addView(aiText)
        root.addView(space(14))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("⚡ ANALISAR / OTIMIZAR", green) { prepareVpn() }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { rightMargin = dp(5) })
        actions.addView(button("■ PARAR", red) { stopVpn() }, LinearLayout.LayoutParams(0, dp(58), .68f).apply { leftMargin = dp(5) })
        root.addView(actions)
        root.addView(space(14))

        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shortcuts.addView(shortcut("IA", "Decisões", cyan) { showTab(Tab.AI) }, LinearLayout.LayoutParams(0, dp(66), 1f).apply { rightMargin = dp(4) })
        shortcuts.addView(shortcut("REDE", "Diagnóstico", green) { showTab(Tab.DIAGNOSTIC) }, LinearLayout.LayoutParams(0, dp(66), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        shortcuts.addView(shortcut("LOG", "Histórico", amber) { showTab(Tab.HISTORY) }, LinearLayout.LayoutParams(0, dp(66), 1f).apply { leftMargin = dp(4) })
        root.addView(shortcuts)
        return scroll
    }

    private fun buildAiScreen(): View {
        val (scroll, root) = screenRoot()
        addHeader(root, "INTELIGÊNCIA LOCAL E MODOS")
        root.addView(cardText("NEXA AI\n$lastAi\n\nDecisão de rede: $lastRecommendation", Color.rgb(8, 22, 34), Color.rgb(26, 83, 114)))
        root.addView(space(12))
        root.addView(section("MODO DE OTIMIZAÇÃO", "Cada modo altera pesos e frequência de medições"))
        listOf(
            NexaMode.AUTO to "Auto AI • equilíbrio geral",
            NexaMode.LATENCY to "Baixa Latência • prioriza resposta",
            NexaMode.NAVIGATION to "Navegação • DNS e estabilidade",
            NexaMode.ECONOMY to "Economia • reduz medições e rádio",
            NexaMode.PRIVACY to "Privacidade Máxima • menos sondagens externas"
        ).forEach { (mode, label) ->
            val selected = settingsStore.mode() == mode
            root.addView(cardText((if (selected) "● " else "○ ") + label, if (selected) Color.rgb(7, 42, 31) else panel, if (selected) green else border).apply {
                setOnClickListener {
                    settingsStore.setMode(mode)
                    showToast("Modo: ${NexaMode.label(mode)}")
                    showTab(Tab.AI)
                    monitor.forceMeasure()
                }
            })
            root.addView(space(8))
        }
        root.addView(cardText("COMO A IA DECIDE\nAnalisa latência, jitter, perda, histórico local, estabilidade e bateria. O modelo é local e não envia suas métricas para nuvem."))
        return scroll
    }

    private fun buildDiagnosticScreen(): View {
        val (scroll, root) = screenRoot()
        addHeader(root, "DIAGNÓSTICO E SAÚDE DA CONEXÃO")
        val s = lastSnapshot
        val health = connectivityHealth()
        root.addView(statusCard("INTERNET VALIDADA", if (health.validated) "OK • Android confirmou acesso à Internet" else "ATENÇÃO • rede ainda não validada", if (health.validated) green else amber))
        root.addView(space(8))
        root.addView(statusCard("IP", "IPv4 ${if (health.ipv4) "OK" else "—"} • IPv6 ${if (health.ipv6) "OK" else "—"}", if (health.ipv4 || health.ipv6) cyan else amber))
        root.addView(space(8))
        root.addView(statusCard("VPN NEXA", if (isVpnActive()) "Ativa • split DNS" else "Desativada", if (isVpnActive()) green else muted))
        root.addView(space(8))
        root.addView(statusCard("DNS / ROTA", lastRoute, cyan))
        root.addView(space(8))
        val privateDns = privateDnsStatus()
        root.addView(statusCard("DNS PRIVADO DO ANDROID", privateDns + if (privateDns.startsWith("Ativo")) "\nO Nexa monitora possíveis conflitos." else "", if (privateDns.startsWith("Ativo")) amber else green))
        root.addView(space(8))
        root.addView(statusCard("WI‑FI", s?.let { if (it.wifi.available) "OK • score ${it.wifi.score()}/100 • ${fmtOrDash(it.wifi.latencyMs)} ms" else "Indisponível" } ?: "Aguardando leitura", cyan))
        root.addView(space(8))
        root.addView(statusCard("CELULAR", s?.let { "${it.radioGeneration} • ${if (it.cellular.available) "OK • score ${it.cellular.score()}/100" else "em espera"}" } ?: "Aguardando leitura", green))
        root.addView(space(8))
        root.addView(statusCard("CONGESTIONAMENTO", s?.let { congestionSummary(it).substringAfter("\n") } ?: "Aguardando amostras", amber))
        root.addView(space(8))
        root.addView(statusCard("COMPATIBILIDADE / FAILSAFE", lastCompat + "\nChatGPT e WhatsApp preservados por bypass quando instalados.", green))
        root.addView(space(14))
        root.addView(button("EXECUTAR DIAGNÓSTICO AGORA", cyan) {
            monitor.forceMeasure()
            showToast("Nova medição iniciada")
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(space(10))
        root.addView(button("ABRIR DNS PRIVADO DO ANDROID", Color.rgb(25, 78, 105)) {
            runCatching { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))
        return scroll
    }

    private fun buildHistoryScreen(): View {
        val (scroll, root) = screenRoot()
        addHeader(root, "HISTÓRICO LOCAL")
        val entries = historyStore.entries()
        root.addView(cardText("HISTÓRICO PRIVADO\n${entries.size} amostras armazenadas somente neste aparelho. Nenhum dado é enviado pelo Nexa."))
        root.addView(space(12))
        if (entries.isEmpty()) {
            root.addView(cardText("Ainda não há histórico suficiente. O Nexa salva no máximo uma amostra a cada 45 segundos quando o histórico local está ativado."))
        } else {
            entries.take(24).forEach { e ->
                root.addView(cardText(buildString {
                    append(historyStore.formatTime(e.timestamp))
                    append("\nWi‑Fi ${e.wifiScore}/100")
                    e.wifiPing?.let { append(" • ${fmt(it)} ms") }
                    append("\n${e.radio} ${e.cellScore}/100")
                    e.cellPing?.let { append(" • ${fmt(it)} ms") }
                }, panel, border))
                root.addView(space(7))
            }
        }
        root.addView(space(8))
        root.addView(button("LIMPAR HISTÓRICO LOCAL", Color.rgb(53, 62, 71)) {
            historyStore.clear()
            showToast("Histórico apagado")
            showTab(Tab.HISTORY)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)))
        return scroll
    }

    private fun buildSettingsScreen(): View {
        val (scroll, root) = screenRoot()
        addHeader(root, "CONFIGURAÇÕES, BATERIA E PRIVACIDADE")
        root.addView(cardText("BATERIA ADAPTATIVA\n$lastPower\n\nTela apagada e bateria baixa reduzem a frequência das medições automaticamente.", Color.rgb(28, 27, 17), Color.rgb(112, 104, 43)))
        root.addView(space(10))
        root.addView(cardText("PRIVACIDADE\nZero analytics • zero telemetria • zero login • IA local • sem histórico de navegação.\n\nConsultas DNS vão apenas ao provedor selecionado quando necessário.", Color.rgb(9, 27, 28), Color.rgb(25, 101, 95)))
        root.addView(space(10))
        val historyEnabled = settingsStore.keepHistory()
        root.addView(cardText("HISTÓRICO LOCAL\n${if (historyEnabled) "Ativado" else "Desativado"} • somente neste aparelho").apply {
            setOnClickListener {
                settingsStore.setKeepHistory(!historyEnabled)
                showTab(Tab.SETTINGS)
            }
        })
        root.addView(space(10))
        root.addView(cardText("COMPATIBILIDADE\n$lastCompat\n\nChatGPT e WhatsApp ficam fora do túnel quando instalados, preservando conectividade."))
        root.addView(space(18))
        root.addView(section("SOBRE", "Informações do projeto"))
        root.addView(cardText("Nexa Network AI • v${appVersion()}\nOtimização local de conectividade para Android\n\nCRÉDITOS\nIdealização: Júlio Pastore\nDesenvolvimento assistido por IA: OpenAI\n© 2026 J.Pastore"))
        return scroll
    }

    private val statusTicker = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(NexaDnsVpnService.PREFS, MODE_PRIVATE)
            lastStatus = prefs.getString(NexaDnsVpnService.KEY_STATUS, "Desativado").orEmpty()
            lastRoute = prefs.getString(NexaDnsVpnService.KEY_ROUTE, "Procurando melhor DNS…").orEmpty()
            lastAi = prefs.getString(NexaDnsVpnService.KEY_AI, "IA local: aguardando ativação").orEmpty()
            lastPower = prefs.getString(NexaDnsVpnService.KEY_POWER, "Economia adaptativa").orEmpty()
            lastCompat = prefs.getString(NexaDnsVpnService.KEY_COMPAT, "Split DNS: pronto").orEmpty()
            updateLiveTexts()
            main.postDelayed(this, 1500)
        }
    }

    private fun updateLiveTexts() {
        if (currentTab != Tab.HOME) return
        val active = isVpnActive()
        vpnText?.text = if (active) "NEXA AI ATIVO\n$lastStatus" else "NEXA AI\nToque em analisar para iniciar"
        statusDot?.text = if (active) "● LIGADO" else "● DESLIGADO"
        statusDot?.setTextColor(if (active) green else muted)
        vpnText?.background = rounded(if (active) Color.rgb(7, 42, 31) else panel, if (active) Color.rgb(18, 124, 82) else border, 22)
        optimizerText?.text = "DNS / ROTA ATUAL\n${if (active) lastRoute else "Cloudflare • Google • Quad9 • DoH"}\n${if (active) "Failsafe pronto" else "Pronto para analisar"}"
        aiText?.text = "NEXA AI\n${lastAi.substringBefore("\n")}\n$lastRecommendation\nModo: ${NexaMode.label(settingsStore.mode())}"
        updatedText?.text = if (lastUpdatedAt > 0) "Última análise: ${secondsAgo(lastUpdatedAt)}" else "Última análise: aguardando"
    }

    private fun render(s: NetworkSnapshot) {
        lastSnapshot = s
        lastRecommendation = s.recommendation
        lastUpdatedAt = System.currentTimeMillis()
        historyStore.record(s)
        if (currentTab != Tab.HOME) return
        wifiText?.text = metricText("Wi‑Fi", s.wifi.available, s.wifi.score(), s.wifi.latencyMs, s.wifi.jitterMs, s.wifi.lossPct, null)
        cellText?.text = metricText("Celular ${s.radioGeneration}", s.cellular.available, s.cellular.score(), s.cellular.latencyMs, s.cellular.jitterMs, s.cellular.lossPct, s.cellular.signalDbm)
        decisionText?.text = decisionSummary(s)
        val dbm = s.cellular.signalDbm
        signalText?.text = buildString {
            append("SINAL CELULAR • toque para detalhes\n")
            if (dbm != null) append("${s.radioGeneration} • $dbm dBm • ${signalQuality(dbm)}")
            else append("${s.radioGeneration} • métrica detalhada indisponível")
            append("\nO Nexa mede e orienta; não amplifica fisicamente a antena.")
        }
        congestionText?.text = congestionSummary(s)
        beforeAfterText?.text = beforeAfterSummary(s)
        updateLiveTexts()
    }

    private fun metricText(title: String, available: Boolean, score: Int, ping: Double?, jitter: Double?, loss: Double?, dbm: Int?): String = buildString {
        append("$title\n${if (available) "● CONECTADO" else "○ INDISPONÍVEL"}")
        append("\n\nScore $score/100")
        append("\nPing ${fmtOrDash(ping)} ms")
        append("\nJitter ${fmtOrDash(jitter)} ms")
        append("\nPerda ${loss?.let { fmt(it) } ?: "—"}%")
        dbm?.let { append("\nSinal $it dBm") }
    }

    private fun decisionSummary(s: NetworkSnapshot): String {
        val ws = s.wifi.score(); val cs = s.cellular.score()
        return when {
            s.wifi.available && s.cellular.available && ws > cs -> "MELHOR ESCOLHA AGORA\nWi‑Fi recomendado • score $ws/100 vs ${s.radioGeneration} $cs/100\n${deltaReason(s.wifi.latencyMs, s.cellular.latencyMs)}"
            s.wifi.available && s.cellular.available && cs > ws -> "MELHOR ESCOLHA AGORA\n${s.radioGeneration} recomendado • score $cs/100 vs Wi‑Fi $ws/100\n${deltaReason(s.cellular.latencyMs, s.wifi.latencyMs)}"
            s.wifi.available && s.cellular.available -> "MELHOR ESCOLHA AGORA\nRedes equilibradas • IA prioriza estabilidade e bateria"
            s.wifi.available -> "MELHOR ESCOLHA AGORA\nWi‑Fi ativo • score $ws/100"
            s.cellular.available -> "MELHOR ESCOLHA AGORA\n${s.radioGeneration} ativo • score $cs/100"
            else -> "MELHOR ESCOLHA AGORA\nAguardando rede com acesso à Internet…"
        }
    }

    private fun deltaReason(best: Double?, other: Double?): String {
        if (best == null || other == null) return "Melhor estabilidade na amostra atual"
        val delta = other - best
        return if (delta > 1) "Resposta ~${fmt(delta)} ms mais rápida" else "Latência semelhante • score decidiu"
    }

    private fun congestionSummary(s: NetworkSnapshot): String {
        val wifi = NetworkIntelligence.assess(s.wifi, false)
        val cell = NetworkIntelligence.assess(s.cellular, true)
        val main = when {
            cell.state.contains("congestionamento", true) -> "${s.radioGeneration}: ${cell.state}"
            wifi.severity > cell.severity -> "Wi‑Fi: ${wifi.state}"
            cell.severity > wifi.severity -> "${s.radioGeneration}: ${cell.state}"
            else -> "Wi‑Fi ${wifi.state.lowercase()} • ${s.radioGeneration} ${cell.state.lowercase()}"
        }
        val detail = when {
            cell.state.contains("congestionamento", true) -> cell.detail
            wifi.severity >= cell.severity -> wifi.detail
            else -> cell.detail
        }
        return "SAÚDE / CONGESTIONAMENTO\n$main\n$detail"
    }

    private fun beforeAfterSummary(s: NetworkSnapshot): String {
        val base = sessionStore.baseline() ?: return "ANTES × AGORA\nAtive o Nexa para registrar uma comparação real."
        val useWifi = s.wifi.available && base.wifiPing != null
        val useCell = !useWifi && s.cellular.available && base.cellPing != null
        if (!useWifi && !useCell) return "ANTES × AGORA\nBaseline registrado • aguardando amostra comparável."
        val beforePing = if (useWifi) base.wifiPing!! else base.cellPing!!
        val nowPing = if (useWifi) s.wifi.latencyMs else s.cellular.latencyMs
        val beforeScore = if (useWifi) base.wifiScore else base.cellScore
        val nowScore = if (useWifi) s.wifi.score() else s.cellular.score()
        val label = if (useWifi) "Wi‑Fi" else s.radioGeneration
        val deltaPing = nowPing?.let { beforePing - it }
        val deltaScore = nowScore - beforeScore
        val verdict = when {
            deltaPing == null -> "Aguardando nova amostra"
            deltaPing > 3.0 || deltaScore >= 5 -> "Melhora medida"
            deltaPing < -3.0 || deltaScore <= -5 -> "Sem ganho agora • IA não deve forçar a mudança"
            else -> "Resultado praticamente igual"
        }
        return buildString {
            append("ANTES × AGORA • $label\n")
            append("Ping ${fmt(beforePing)} → ${fmtOrDash(nowPing)} ms • Score $beforeScore → $nowScore\n")
            append(verdict)
            if (isVpnActive()) append(" • DNS atual: $lastRoute")
        }
    }

    private data class ConnectivityHealth(val validated: Boolean, val ipv4: Boolean, val ipv6: Boolean)

    private fun connectivityHealth(): ConnectivityHealth {
        return try {
            val cm = getSystemService(ConnectivityManager::class.java)
            var validated = false
            var ipv4 = false
            var ipv6 = false
            for (network in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(network) ?: continue
                if (!caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                    !caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) continue
                if (caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)) validated = true
                val lp = cm.getLinkProperties(network) ?: continue
                for (la in lp.linkAddresses) {
                    if (la.address is Inet4Address) ipv4 = true
                    if (la.address is Inet6Address && !la.address.isLinkLocalAddress) ipv6 = true
                }
            }
            ConnectivityHealth(validated, ipv4, ipv6)
        } catch (_: Exception) {
            ConnectivityHealth(false, false, false)
        }
    }

    private fun privateDnsStatus(): String {
        if (Build.VERSION.SDK_INT < 28) return "Não disponível nesta versão do Android"
        return try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val lp = cm.getLinkProperties(cm.activeNetwork)
            when {
                lp?.isPrivateDnsActive == true -> "Ativo${lp.privateDnsServerName?.let { " • $it" } ?: ""}"
                else -> "Desativado / automático"
            }
        } catch (_: Exception) { "Não foi possível consultar" }
    }

    private fun isVpnActive(): Boolean = lastStatus.contains("ativa", true) || lastStatus.contains("iniciando", true) || lastStatus.contains("selecionando", true)

    private fun showSignalDialog() {
        val s = lastSnapshot
        val dbm = s?.cellular?.signalDbm
        showDialog("Assistente de sinal", buildString {
            append("Tecnologia: ${s?.radioGeneration ?: "—"}\n")
            append("Potência: ${dbm?.let { "$it dBm" } ?: "—"}\n")
            append("Qualidade: ${dbm?.let { signalQuality(it) } ?: "—"}\n\n")
            append(s?.radioDetail?.takeIf { it.isNotBlank() } ?: "Métrica detalhada indisponível.")
            append("\n\nO Nexa não aumenta a potência da torre ou antena. Ele mede, compara e evita estratégias ruins.")
        })
    }

    private fun prepareVpn() {
        if (!isVpnActive()) sessionStore.capture(lastSnapshot)
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, vpnRequestCode) else startVpn()
    }

    @Deprecated("Legacy result API kept to support minSdk without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        val intent = Intent(this, NexaDnsVpnService::class.java).setAction(NexaDnsVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopVpn() {
        startService(Intent(this, NexaDnsVpnService::class.java).setAction(NexaDnsVpnService.ACTION_STOP))
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 901)
    }

    private fun clearHomeRefs() {
        wifiText = null; cellText = null; optimizerText = null; vpnText = null; statusDot = null
        aiText = null; decisionText = null; signalText = null; congestionText = null; beforeAfterText = null; updatedText = null
    }

    private fun showDialog(title: String, message: String) = AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    private fun showToast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()

    private fun signalQuality(dbm: Int) = when {
        dbm >= -85 -> "Excelente"
        dbm >= -95 -> "Bom"
        dbm >= -105 -> "Regular"
        dbm >= -115 -> "Fraco"
        else -> "Muito fraco"
    }

    @Suppress("DEPRECATION")
    private fun appVersion(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (_: Exception) { "?" }

    private fun secondsAgo(time: Long): String {
        val s = ((System.currentTimeMillis() - time) / 1000).coerceAtLeast(0)
        return if (s < 5) "agora" else "há ${s}s"
    }

    private fun statusCard(title: String, value: String, accent: Int): TextView = cardText("$title\n$value", panel, accent)

    private fun section(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, 0, 0, dp(8))
        addView(text(title, 15, true, Color.WHITE))
        addView(text(subtitle, 11, false, muted))
    }

    private fun networkCard(title: String, accent: Int): TextView = text("$title\nAguardando medição…", 12, false, Color.WHITE).apply {
        setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(panel2, accent, 19); minHeight = dp(152)
    }

    private fun cardText(initial: String, fill: Int = panel, stroke: Int = border): TextView = text(initial, 12, false, Color.WHITE).apply {
        setPadding(dp(15), dp(14), dp(15), dp(14)); background = rounded(fill, stroke, 19)
    }

    private fun shortcut(top: String, bottom: String, accent: Int, action: () -> Unit): TextView = text("$top\n$bottom", 10, true, accent).apply {
        gravity = Gravity.CENTER; background = rounded(panel, border, 16); setOnClickListener { action() }
    }

    private fun button(label: String, accent: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f; setTextColor(if (accent == green || accent == cyan) Color.rgb(0, 24, 24) else Color.WHITE)
        setTypeface(typeface, Typeface.BOLD); background = rounded(accent, accent, 16); setOnClickListener { action() }
    }

    private fun pill(label: String, color: Int, fill: Int): TextView = text(label, 10, true, color).apply {
        gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(4)); background = rounded(fill, color, 13)
    }

    private fun text(value: String, size: Int, bold: Boolean, color: Int): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE; setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }

    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fmt(v: Double) = String.format(Locale.US, "%.1f", v)
    private fun fmtOrDash(v: Double?) = v?.let { fmt(it) } ?: "—"
}
