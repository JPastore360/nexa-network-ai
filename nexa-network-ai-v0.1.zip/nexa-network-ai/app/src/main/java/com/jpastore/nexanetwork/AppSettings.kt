package com.jpastore.nexanetwork

import android.content.Context

object NexaMode {
    const val AUTO = "AUTO"
    const val LATENCY = "LATENCY"
    const val NAVIGATION = "NAVIGATION"
    const val ECONOMY = "ECONOMY"
    const val PRIVACY = "PRIVACY"

    fun label(mode: String): String = when (mode) {
        LATENCY -> "Baixa latência"
        NAVIGATION -> "Navegação"
        ECONOMY -> "Economia"
        PRIVACY -> "Privacidade máxima"
        else -> "Auto AI"
    }
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_user_settings", Context.MODE_PRIVATE)

    fun mode(): String = prefs.getString("mode", NexaMode.AUTO) ?: NexaMode.AUTO
    fun setMode(mode: String) = prefs.edit().putString("mode", mode).apply()

    fun keepHistory(): Boolean = prefs.getBoolean("keep_history", true)
    fun setKeepHistory(value: Boolean) = prefs.edit().putBoolean("keep_history", value).apply()
}
