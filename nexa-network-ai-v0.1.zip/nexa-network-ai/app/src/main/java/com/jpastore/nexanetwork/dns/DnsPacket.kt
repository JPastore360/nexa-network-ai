package com.jpastore.nexanetwork.dns

import java.nio.ByteBuffer
import java.nio.ByteOrder

data class DnsTunQuery(
    val sourceIp: ByteArray,
    val destinationIp: ByteArray,
    val sourcePort: Int,
    val dnsPayload: ByteArray
)

object DnsPacket {
    fun parseIpv4UdpDns(packet: ByteArray): DnsTunQuery? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0x0F
        if (version != 4) return null
        val ihl = (packet[0].toInt() and 0x0F) * 4
        if (ihl < 20 || packet.size < ihl + 8) return null
        val protocol = packet[9].toInt() and 0xFF
        if (protocol != 17) return null

        val udp = ihl
        val sourcePort = u16(packet, udp)
        val destinationPort = u16(packet, udp + 2)
        if (destinationPort != 53) return null

        val udpLength = u16(packet, udp + 4)
        if (udpLength < 8) return null
        val payloadStart = udp + 8
        val payloadLength = (udpLength - 8).coerceAtMost(packet.size - payloadStart)
        if (payloadLength < 12) return null

        return DnsTunQuery(
            sourceIp = packet.copyOfRange(12, 16),
            destinationIp = packet.copyOfRange(16, 20),
            sourcePort = sourcePort,
            dnsPayload = packet.copyOfRange(payloadStart, payloadStart + payloadLength)
        )
    }

    fun buildIpv4UdpResponse(query: DnsTunQuery, dnsResponse: ByteArray): ByteArray {
        val totalLength = 20 + 8 + dnsResponse.size
        val out = ByteArray(totalLength)
        out[0] = 0x45
        out[1] = 0
        putU16(out, 2, totalLength)
        putU16(out, 4, (System.nanoTime() and 0xFFFF).toInt())
        putU16(out, 6, 0x4000)
        out[8] = 64
        out[9] = 17
        query.destinationIp.copyInto(out, 12)
        query.sourceIp.copyInto(out, 16)

        putU16(out, 10, 0)
        putU16(out, 10, ipChecksum(out, 0, 20))

        val udp = 20
        putU16(out, udp, 53)
        putU16(out, udp + 2, query.sourcePort)
        putU16(out, udp + 4, 8 + dnsResponse.size)
        // UDP checksum = 0 is valid for IPv4 and keeps the proxy lightweight.
        putU16(out, udp + 6, 0)
        dnsResponse.copyInto(out, udp + 8)
        return out
    }

    fun buildProbeQuery(id: Int, host: String = "example.com"): ByteArray {
        val labels = host.split('.').filter { it.isNotBlank() }
        val size = 12 + labels.sumOf { 1 + it.toByteArray(Charsets.US_ASCII).size } + 1 + 4
        val b = ByteBuffer.allocate(size).order(ByteOrder.BIG_ENDIAN)
        b.putShort((id and 0xFFFF).toShort())
        b.putShort(0x0100.toShort()) // recursion desired
        b.putShort(1) // qdcount
        b.putShort(0)
        b.putShort(0)
        b.putShort(0)
        for (label in labels) {
            val bytes = label.toByteArray(Charsets.US_ASCII)
            b.put(bytes.size.toByte())
            b.put(bytes)
        }
        b.put(0)
        b.putShort(1) // A
        b.putShort(1) // IN
        return b.array()
    }

    fun responseMatchesQuery(query: ByteArray, response: ByteArray): Boolean {
        if (query.size < 2 || response.size < 12) return false
        return query[0] == response[0] && query[1] == response[1] &&
            ((response[2].toInt() and 0x80) != 0)
    }

    private fun u16(data: ByteArray, offset: Int): Int =
        ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)

    private fun putU16(data: ByteArray, offset: Int, value: Int) {
        data[offset] = ((value ushr 8) and 0xFF).toByte()
        data[offset + 1] = (value and 0xFF).toByte()
    }

    private fun ipChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += (((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)).toLong()
            while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
            i += 2
        }
        if (i < end) {
            sum += ((data[i].toInt() and 0xFF) shl 8).toLong()
            while ((sum ushr 16) != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return sum.inv().toInt() and 0xFFFF
    }
}
