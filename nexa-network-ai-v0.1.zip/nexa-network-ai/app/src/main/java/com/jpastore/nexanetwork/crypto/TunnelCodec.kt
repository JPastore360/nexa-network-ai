package com.jpastore.nexanetwork.crypto

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object TunnelCodec {
    const val TYPE_DATA: Byte = 1
    const val TYPE_PING: Byte = 2
    const val TYPE_PONG: Byte = 3
    private const val MAGIC = 0x4E584E31
    private const val VERSION: Byte = 1
    const val HEADER_SIZE = 24

    data class Message(
        val type: Byte,
        val path: Byte,
        val session: Long,
        val seq: Long,
        val payload: ByteArray
    )

    fun encode(
        passphrase: String,
        type: Byte,
        path: Byte,
        session: Long,
        seq: Long,
        direction: Int,
        payload: ByteArray
    ): ByteArray {
        val header = ByteBuffer.allocate(HEADER_SIZE).order(ByteOrder.BIG_ENDIAN)
            .putInt(MAGIC)
            .put(VERSION)
            .put(type)
            .put(path)
            .put(0)
            .putLong(session)
            .putLong(seq)
            .array()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(passphrase), GCMParameterSpec(128, nonce(session, seq, direction)))
        cipher.updateAAD(header)
        val encrypted = cipher.doFinal(payload)
        return header + encrypted
    }

    fun decode(passphrase: String, datagram: ByteArray, direction: Int): Message? {
        if (datagram.size < HEADER_SIZE + 16) return null
        val bb = ByteBuffer.wrap(datagram, 0, HEADER_SIZE).order(ByteOrder.BIG_ENDIAN)
        if (bb.int != MAGIC) return null
        if (bb.get() != VERSION) return null
        val type = bb.get()
        val path = bb.get()
        bb.get()
        val session = bb.long
        val seq = bb.long
        val header = datagram.copyOfRange(0, HEADER_SIZE)
        val encrypted = datagram.copyOfRange(HEADER_SIZE, datagram.size)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(passphrase), GCMParameterSpec(128, nonce(session, seq, direction)))
            cipher.updateAAD(header)
            Message(type, path, session, seq, cipher.doFinal(encrypted))
        } catch (_: Exception) {
            null
        }
    }

    private fun key(passphrase: String): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256").digest(passphrase.toByteArray(Charsets.UTF_8))
        return SecretKeySpec(digest, "AES")
    }

    private fun nonce(session: Long, seq: Long, direction: Int): ByteArray {
        val sessionHash = (session xor (session ushr 32)).toInt() xor if (direction == 1) Int.MIN_VALUE else 0
        return ByteBuffer.allocate(12).order(ByteOrder.BIG_ENDIAN)
            .putInt(sessionHash)
            .putLong(seq)
            .array()
    }
}
