package com.jpastore.nexanetwork.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.system.OsConstants
import com.jpastore.nexanetwork.MainActivity
import com.jpastore.nexanetwork.R
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.Executors

class NexaVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.jpastore.nexanetwork.START"
        const val ACTION_STOP = "com.jpastore.nexanetwork.STOP"
        const val PREFS = "nexa_network"
        const val KEY_HOST = "server_host"
        const val KEY_PORT = "server_port"
        const val KEY_SECRET = "server_secret"
        const val KEY_STATUS = "vpn_status"
        private const val CHANNEL_ID = "nexa_vpn_active"
        private const val NOTIFICATION_ID = 7001
    }

    private var engine: TunnelEngine? = null
    private val startup = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification("Iniciando otimização…"))
        startup.submit { startTunnel() }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onDestroy() {
        stopTunnel()
        startup.shutdownNow()
        super.onDestroy()
    }

    private fun startTunnel() {
        if (engine != null) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val host = prefs.getString(KEY_HOST, "")?.trim().orEmpty()
        val port = prefs.getInt(KEY_PORT, 51888)
        val secret = prefs.getString(KEY_SECRET, "")?.trim().orEmpty()
        if (host.isBlank() || secret.length < 12 || secret == "CHANGE-ME-NOW") {
            updateStatus("Configure servidor e chave antes de ativar")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        try {
            val resolved = InetAddress.getByName(host)
            val endpoint = InetSocketAddress(resolved, port)
            val builder = Builder()
                .setSession("Nexa Network AI")
                .setMtu(1280)
                .addAddress("10.77.0.2", 24)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("1.1.1.1")
            if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
            builder.allowFamily(OsConstants.AF_INET6)
            val tun = builder.establish() ?: error("Falha ao criar interface VPN")

            engine = TunnelEngine(
                service = this,
                tun = tun,
                endpoint = endpoint,
                passphrase = secret,
                onNetworksChanged = { networks -> setUnderlyingNetworks(networks) },
                onStatus = { updateStatus(it) }
            ).also { it.start() }
        } catch (e: Exception) {
            updateStatus("Falha: ${e.message ?: e.javaClass.simpleName}")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopTunnel() {
        engine?.stop()
        engine = null
        updateStatus("Desativado", notify = false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateStatus(status: String, notify: Boolean = true) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_STATUS, status).apply()
        if (notify) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, notification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Nexa Network • Conexão ativa",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mostra quando o Smart Multipath está ativo"
                enableLights(false)
                enableVibration(false)
                setShowBadge(true)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun notification(status: String): Notification {
        val launch = Intent(this, MainActivity::class.java)
        val openPi = PendingIntent.getActivity(
            this, 1, launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, NexaVpnService::class.java).setAction(ACTION_STOP)
        val stopPi = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            R.drawable.ic_nexa_status,
            "Parar",
            stopPi
        ).build()

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Nexa Network AI • ATIVO")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_nexa_status)
            .setColor(Color.rgb(0, 200, 255))
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(action)
            .build()
    }
}
