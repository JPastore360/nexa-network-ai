# Nexa Network AI — V0.2 Smart Multipath

Projeto Android sem root + servidor Linux para otimização real de conectividade usando Wi‑Fi e rede celular (2G/3G/4G/5G quando disponíveis).

## O que já existe no código

- Android Kotlin, minSdk 26, target/compileSdk 35.
- Interface redesenhada com identidade visual NEXA.
- Ícone/logotipo próprio do aplicativo.
- Notificação persistente com ícone NEXA enquanto o Smart Multipath estiver ativo e ação rápida para parar.
- Detecção de Wi‑Fi e celular.
- Classificação 2G / 3G / 4G / 5G, incluindo indicação 5G NSA quando exposta pelo Android.
- Leitura de métricas de rádio quando permitidas pelo modem/API.
- Medição independente de latência, jitter aproximado e perda por caminho.
- Score de rede local e recomendação automática.
- `VpnService` sem root.
- Solicitação paralela de Wi‑Fi e rede celular.
- Dois canais UDP vinculados explicitamente às duas redes.
- Heartbeat e RTT do túnel por caminho.
- Multipath por fluxo com peso dinâmico de RTT.
- Failover para o caminho saudável.
- Túnel criptografado AES-256-GCM.
- Servidor Linux em Go com TUN + NAT.
- GitHub Actions para gerar APK e binários Linux.
- `applicationId` preservado (`com.jpastore.nexanetwork`) e versionamento crescente para atualização por cima.

## Importante

O bonding atual é **por fluxo**. Conexões simultâneas podem usar Wi‑Fi e celular em paralelo sem embaralhar pacotes do mesmo fluxo. Ainda não há promessa de somar as velocidades em um único download TCP.

O projeto não aumenta potência de antena e não cria cobertura onde não existe. 2G/3G/4G/5G são tratados como caminhos celulares disponíveis e a geração detectada entra na decisão local.

## Atualizações sem desinstalar

A partir da V0.2, use sempre a mesma chave de assinatura configurada no GitHub Actions. O workflow usa os secrets `NEXA_KEYSTORE_B64` e `NEXA_SIGNING_PASSWORD`. Guarde uma cópia privada do arquivo de assinatura; nunca envie essa chave ao repositório.

## Compilação pelo celular

Veja [`docs/PASSO_A_PASSO_CELULAR.md`](docs/PASSO_A_PASSO_CELULAR.md).

## Arquitetura

Veja [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md).
