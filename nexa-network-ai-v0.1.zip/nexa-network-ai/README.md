# Nexa Network AI — V0.1 Smart Multipath

Projeto Android sem root + servidor Linux para otimização real de conectividade usando Wi‑Fi e rede celular (2G/3G/4G/5G quando disponíveis).

## O que já existe no código

- Android Kotlin, minSdk 26, target/compileSdk 35.
- Detecção de Wi‑Fi e celular.
- Classificação 2G / 3G / 4G / 5G, incluindo indicação 5G NSA em Android moderno quando exposta pelo sistema.
- Leitura de métricas de rádio quando permitidas pelo modem/API.
- Medição independente de latência, jitter aproximado e perda por caminho.
- Score de rede local.
- `VpnService` sem root.
- Solicitação paralela de Wi‑Fi e rede celular.
- Dois canais UDP vinculados explicitamente às duas redes.
- Heartbeat e RTT do túnel por caminho.
- Multipath por fluxo com peso dinâmico de RTT.
- Failover para o caminho saudável.
- Túnel criptografado AES-256-GCM.
- Servidor Linux em Go com TUN + NAT.
- GitHub Actions para gerar APK e binários Linux.

## Importante

Esta é a primeira versão funcional da arquitetura V3, mas o bonding implementado é **por fluxo**. Isso permite que conexões simultâneas usem Wi‑Fi e celular em paralelo sem embaralhar pacotes do mesmo fluxo. Não há promessa de somar as velocidades em um único download TCP.

O projeto não aumenta potência de antena e não cria 5G onde não existe. 2G/3G/4G/5G usam o mesmo canal celular; a geração é detectada e medida para a decisão local.

## Compilação pelo celular

Veja [`docs/PASSO_A_PASSO_CELULAR.md`](docs/PASSO_A_PASSO_CELULAR.md).

## Arquitetura

Veja [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md).
