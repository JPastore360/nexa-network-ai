# Nexa Network AI

Aplicativo Android pessoal para otimização leve de navegação sem root e sem servidor externo.

## O que esta versão faz

- monitora Wi‑Fi e rede celular (2G/3G/4G/5G);
- mede ping, jitter, perda e score;
- cria uma VPN local somente para DNS;
- testa Cloudflare, Google e Quad9;
- escolhe automaticamente a combinação DNS/rede com melhor resposta;
- faz failover de DNS quando a rota escolhida falha;
- mantém notificação persistente enquanto a otimização está ativa;
- usa assinatura fixa do projeto e `applicationId` estável para atualização por cima.

A VPN local captura somente o tráfego DNS destinado ao resolvedor virtual. O tráfego normal de navegação continua saindo diretamente pela rede do Android, reduzindo consumo e complexidade.
