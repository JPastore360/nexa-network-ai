# Nexa Network AI v0.9.1

Otimização local de conectividade Android com DNS inteligente, IA local, detecção de congestionamento, comparação Antes × Agora, Health Check, histórico local, bateria adaptativa, splash screen e submenus.

- applicationId: `com.jpastore.nexanetwork`
- versionCode: `9`
- versionName: `0.9.1`
- sem analytics / telemetria
- assinatura de atualização preservada


## 0.9.1
- Cabeçalho de status redesenhado sem bloco verde excessivo.
- Diagnóstico de cobertura fraca separado de congestionamento.
- Jitter/latência sem amostra mostram “calculando…”.
- Mensagem Antes × Agora orienta reiniciar sessão quando não há baseline.
