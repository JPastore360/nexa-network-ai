# Nexa Network AI v0.5.0

Otimizador de navegação Android para uso pessoal, sem root e com foco em privacidade.

## O que esta versão faz
- Monitora Wi-Fi e rede celular 2G/3G/4G/5G.
- Mede responsividade local por rede (latência TCP, jitter estimado, perda e score).
- Usa VPN local apenas para interceptar consultas DNS do aparelho.
- Encaminha DNS via DNS-over-HTTPS (DoH/TLS) para Cloudflare, Google ou Quad9.
- Escolhe automaticamente a rota/provedor que está respondendo melhor e faz failover.
- Não usa analytics, login, telemetria ou servidor próprio.
- Mantém notificação persistente enquanto a otimização está ativa.

## Privacidade
O Nexa não envia suas métricas de rede, localização, identificadores do aparelho ou histórico de navegação para um backend próprio. Como qualquer resolvedor DNS, o provedor DoH escolhido recebe as consultas DNS necessárias e pode observar o IP público da conexão usada.

## Atualização
`applicationId`: `com.jpastore.nexanetwork`

A assinatura embutida no projeto e o `versionCode` crescente permitem instalar novas versões por cima da v0.4.
