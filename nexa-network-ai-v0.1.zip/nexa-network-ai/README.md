# Nexa Network AI v0.6.0

Otimizador local de navegação para Android, sem servidor próprio e sem telemetria.

## v0.6
- NEXA AI local adaptativa: aprende latência e confiabilidade por DNS/rede sem nuvem.
- DoH com Cloudflare, Google e Quad9.
- Fallback para DNS nativo se DoH falhar.
- Failsafe: se a resolução falhar repetidamente, a VPN é desligada para preservar a Internet.
- Split DNS: somente DNS usa o túnel local.
- Compatibilidade: ChatGPT, WhatsApp e WhatsApp Business ficam fora do túnel quando instalados.
- Monitoramento passivo de Wi-Fi/2G/3G/4G/5G, sem manter o rádio celular acordado à força.
- Economia adaptativa: reduz medições com tela apagada ou bateria baixa.
- Zero analytics, zero login, zero telemetria.

O nome do ZIP do projeto permanece `nexa-network-ai-v0.1.zip` para manter o fluxo simples de build.
