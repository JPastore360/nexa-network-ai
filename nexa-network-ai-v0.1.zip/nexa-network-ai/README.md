# Nexa Network AI v0.9.0

Otimização local de conectividade Android com DNS inteligente, IA local, detecção de congestionamento, comparação Antes × Agora, Health Check, histórico local, bateria adaptativa, splash screen e submenus.

- applicationId: `com.jpastore.nexanetwork`
- versionCode: `9`
- versionName: `0.9.0`
- sem analytics / telemetria
- assinatura de atualização preservada
