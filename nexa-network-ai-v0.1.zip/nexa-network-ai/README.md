# Nexa Network AI

Versão 0.8.0. Otimizador local de conectividade para Android com DNS inteligente (DoH), IA local, failsafe, monitoramento de Wi‑Fi/2G/3G/4G/5G, modos de otimização, histórico local, diagnóstico, economia adaptativa de bateria, assistente de sinal, splash screen e navegação por submenus.

## Privacidade
Zero analytics, zero telemetria, zero login e aprendizado local. O histórico pode ser desativado e apagado pelo próprio app.

## Atualização
Mantém o mesmo `applicationId` e a mesma assinatura das versões anteriores para instalação por cima.
