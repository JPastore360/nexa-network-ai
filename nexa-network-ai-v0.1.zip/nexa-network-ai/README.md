# Nexa Network AI

Versão 0.7.0. Otimizador local de navegação para Android com DNS inteligente (DoH), IA local, failsafe, monitoramento de Wi-Fi/2G/3G/4G/5G, economia adaptativa de bateria e assistente de sinal.

## Privacidade
Sem analytics, telemetria, login ou IA em nuvem. Métricas e aprendizado permanecem no aparelho.

## Importante
O aplicativo não amplifica fisicamente o sinal da torre ou da antena. Ele mede a qualidade do rádio e da rede, escolhe DNS/rota mais adequados e evita decisões que prejudiquem a conectividade.
