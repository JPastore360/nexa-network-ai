# Arquitetura — Nexa Network AI

## Objetivo

O projeto usa uma VPN Android sem root para capturar o tráfego IPv4 e transportá-lo até um servidor Linux por um ou dois caminhos físicos simultâneos:

- Wi‑Fi
- Rede celular, independentemente de ser 2G, 3G, 4G/LTE ou 5G/NR

O Android usa `ConnectivityManager.requestNetwork()` para tentar manter Wi‑Fi e celular disponíveis ao mesmo tempo. Cada socket UDP é explicitamente vinculado à sua `Network` e protegido contra recursão na própria VPN.

## Fluxo

```text
Apps Android
    |
VpnService / TUN 10.77.0.2
    |
Smart Multipath Engine
    |---------------------|
    |                     |
 Wi‑Fi UDP             Celular UDP
    |                     |
    |--------- Internet --|
              |
       Nexa Server UDP
              |
          TUN nexa0
              |
       NAT / Internet
```

## V0.1 — comportamento implementado

1. Detecta Wi‑Fi e celular separadamente.
2. Identifica 2G/3G/4G/5G quando o modem/Android expõe a informação.
3. Mede latência TCP, jitter aproximado e perda de tentativas em cada caminho.
4. Calcula score local.
5. Solicita Wi‑Fi e celular ao Android em paralelo.
6. Cria dois sockets UDP, cada um preso a uma rede física.
7. Captura IPv4 com `VpnService`.
8. Distribui **fluxos** entre Wi‑Fi e celular usando hash estável e peso baseado no RTT do túnel.
9. Faz heartbeat independente nos dois caminhos.
10. Se um caminho deixa de responder, novos pacotes usam o caminho saudável.
11. Servidor Linux descriptografa, injeta em TUN e usa NAT para a Internet.
12. Respostas são devolvidas pelo caminho correspondente ao hash do fluxo, com failover se necessário.

## O que esta versão ainda NÃO afirma fazer

- Não soma necessariamente Wi‑Fi + celular em um único download TCP.
- Não aumenta potência física de antena.
- Não força 5G/4G se o modem/operadora não disponibilizar a tecnologia.
- IPv6 passa fora do túnel na V0.1; o multipath atual é IPv4.
- O motor de decisão V0.1 é heurístico/local; um modelo adaptativo pode ser adicionado depois dos testes reais.

## Segurança

Os datagramas usam AES-256-GCM. A chave de 256 bits é derivada via SHA-256 da senha compartilhada. Cada pacote usa nonce derivado da sessão, direção e sequência e autentica o cabeçalho como AAD.

Para distribuição pública futura, substituir a chave compartilhada por handshake autenticado, chaves por dispositivo e rotação automática.
