# Passo a passo — tudo pelo celular

## Parte A — colocar no GitHub usando Termux

1. Instale o Termux por uma fonte oficial/atualizada.
2. Abra o Termux e execute:

```bash
pkg update
pkg install git gh unzip
termux-setup-storage
```

3. Baixe `nexa-network-ai.zip` no celular e deixe em Downloads.
4. No Termux:

```bash
cd ~
unzip ~/storage/downloads/nexa-network-ai.zip
cd nexa-network-ai
git init
git branch -M main
git add .
git commit -m "Nexa Network AI v0.1"
gh auth login
gh repo create nexa-network-ai --private --source=. --remote=origin --push
```

O login do `gh` abre o processo oficial de autenticação do GitHub; não use sua senha do GitHub como senha do `git`.

## Parte B — gerar o APK no GitHub

1. Abra o repositório `nexa-network-ai` no navegador/GitHub.
2. Entre em **Actions**.
3. Abra **Build Android APK**.
4. O push para `main` já dispara a compilação. Também existe **Run workflow** para executar manualmente.
5. Quando concluir, abra a execução e baixe o artifact **Nexa-Network-AI-debug**.
6. Extraia o ZIP do artifact e instale `app-debug.apk`.

## Parte C — servidor gratuito

O bonding/multipath de Internet precisa de um computador externo com IP público. O repositório inclui o servidor; ele não usa API paga.

Uma opção é uma VM elegível ao **Oracle Cloud Always Free**. A disponibilidade de máquinas gratuitas depende da região/capacidade e o cadastro da Oracle pode exigir cartão para verificação.

Na VM Ubuntu:

```bash
sudo apt update
sudo apt install -y git golang-go iptables

git clone https://github.com/SEU_USUARIO/nexa-network-ai.git
cd nexa-network-ai

export NEXA_KEY='ESCOLHA-UMA-CHAVE-FORTE-COM-20-CARACTERES-OU-MAIS'
sudo -E bash scripts/install-service.sh
```

Depois confira:

```bash
sudo systemctl status nexa-network
```

No painel do provedor, libere **UDP 51888** para a VM. O script também tenta liberar a porta no UFW quando ele existe.

## Parte D — configurar o APK

1. Abra **Nexa Network AI**.
2. Autorize Telefone/Localização se quiser identificação e métricas detalhadas de 2G/3G/4G/5G. A localização não é enviada ao servidor; a permissão é usada pelas APIs de rádio do Android.
3. Em **Servidor V3**, informe o IPv4 público da VM.
4. Porta: `51888`.
5. Chave: exatamente a mesma usada em `NEXA_KEY` no servidor.
6. Toque **SALVAR SERVIDOR**.
7. Toque **ATIVAR SMART MULTIPATH**.
8. Aceite a solicitação de VPN do Android.

## Parte E — primeiro teste

Faça primeiro com Wi‑Fi + dados móveis ligados.

A tela deve mostrar duas leituras quando o aparelho/operadora permitir os dois caminhos simultaneamente:

- Wi‑Fi
- Celular 2G, 3G, 4G ou 5G

Com o túnel ativo, abra sites normalmente. Depois:

1. desligue o Wi‑Fi e verifique se a navegação continua pelo celular;
2. ligue novamente o Wi‑Fi;
3. observe o status `Smart Multipath ativo • Wi‑Fi + celular`;
4. compare ping/jitter antes e depois;
5. teste múltiplas conexões/downloads, que é onde o bonding por fluxo desta versão é mais perceptível.

## Se não aparecer Wi‑Fi + celular juntos

Alguns fabricantes/operadoras não mantêm a interface celular utilizável enquanto o Wi‑Fi está ativo, mesmo quando um app solicita a rede. O app tenta explicitamente manter as duas redes, mas não consegue substituir uma restrição do modem, firmware ou operadora sem root.
