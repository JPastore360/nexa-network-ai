# Nexa Network AI v0.2

- Interface redesenhada em tema escuro com identidade NEXA.
- Logotipo/ícone próprio do app.
- Ícone persistente na barra de notificações enquanto a VPN/Smart Multipath estiver ativo.
- Ação "Parar" diretamente na notificação.
- Wi‑Fi e celular 2G/3G/4G/5G exibidos lado a lado, com score, ping, jitter e perda.
- Ajustes leves no motor: menos threads no monitor, heartbeat de failover mais responsivo e buffers UDP maiores.
- `applicationId` preservado: `com.jpastore.nexanetwork`.
- `versionCode` atualizado para 2 / `versionName` 0.2.0.
- Build preparada para assinatura fixa via GitHub Secrets, permitindo futuras instalações por cima.

## Assinatura
Nunca envie o arquivo `nexa-update-key.jks` para o repositório. A build deve reconstruí-lo usando os secrets `NEXA_KEYSTORE_B64` e `NEXA_SIGNING_PASSWORD`.
