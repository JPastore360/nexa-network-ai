#!/usr/bin/env bash
set -euo pipefail

PORT="${NEXA_PORT:-51888}"
TUN="${NEXA_TUN:-nexa0}"
WAN="${WAN_IFACE:-$(ip route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1);exit}}')}"

if [[ $EUID -ne 0 ]]; then
  echo "Execute com sudo: sudo bash scripts/setup-server.sh"
  exit 1
fi

modprobe tun || true
ip tuntap add dev "$TUN" mode tun 2>/dev/null || true
ip addr replace 10.77.0.1/24 dev "$TUN"
ip link set "$TUN" up
sysctl -w net.ipv4.ip_forward=1

iptables -t nat -C POSTROUTING -s 10.77.0.0/24 -o "$WAN" -j MASQUERADE 2>/dev/null || \
  iptables -t nat -A POSTROUTING -s 10.77.0.0/24 -o "$WAN" -j MASQUERADE
iptables -C FORWARD -i "$TUN" -o "$WAN" -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i "$TUN" -o "$WAN" -j ACCEPT
iptables -C FORWARD -i "$WAN" -o "$TUN" -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i "$WAN" -o "$TUN" -m state --state RELATED,ESTABLISHED -j ACCEPT

if command -v ufw >/dev/null 2>&1; then
  ufw allow "${PORT}/udp" || true
fi

echo "Servidor preparado. Interface WAN: $WAN | TUN: $TUN | UDP: $PORT"
echo "Ainda é necessário liberar UDP $PORT no firewall/security list do provedor cloud."
