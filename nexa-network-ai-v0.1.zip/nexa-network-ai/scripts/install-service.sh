#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Execute com sudo preservando a chave: sudo -E bash scripts/install-service.sh"
  exit 1
fi
: "${NEXA_KEY:?Antes execute: export NEXA_KEY='uma-chave-forte-com-20-ou-mais-caracteres'}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${NEXA_PORT:-51888}"
TUN="${NEXA_TUN:-nexa0}"

cd "$ROOT/server"
go build -o /usr/local/bin/nexa-server .
mkdir -p /usr/local/lib/nexa-network
cp "$ROOT/scripts/setup-server.sh" /usr/local/lib/nexa-network/setup-server.sh
chmod +x /usr/local/bin/nexa-server /usr/local/lib/nexa-network/setup-server.sh

cat > /etc/nexa-network.env <<ENV
NEXA_KEY=$NEXA_KEY
NEXA_PORT=$PORT
NEXA_TUN=$TUN
ENV
chmod 600 /etc/nexa-network.env

cat > /etc/systemd/system/nexa-network.service <<'UNIT'
[Unit]
Description=Nexa Network AI Multipath Tunnel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile=/etc/nexa-network.env
ExecStartPre=/usr/local/lib/nexa-network/setup-server.sh
ExecStart=/usr/local/bin/nexa-server
Restart=always
RestartSec=2
User=root

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now nexa-network.service
systemctl --no-pager --full status nexa-network.service || true
