#!/usr/bin/env bash
set -euo pipefail
: "${NEXA_KEY:?Defina NEXA_KEY com a mesma chave usada no Android}"
export NEXA_PORT="${NEXA_PORT:-51888}"
export NEXA_TUN="${NEXA_TUN:-nexa0}"
cd "$(dirname "$0")/../server"
go build -o nexa-server .
sudo -E ./nexa-server
