module github.com/jpastore/nexa-network-ai/server

go 1.21
