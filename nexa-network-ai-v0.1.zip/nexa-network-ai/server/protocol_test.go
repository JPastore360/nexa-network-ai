package main

import (
	"bytes"
	"testing"
)

func TestCodecRoundTrip(t *testing.T) {
	codec := NewCodec("a-very-long-test-secret")
	original := Message{Type: typeData, Path: 2, Session: 42, Seq: 99, Payload: []byte("hello")}
	encoded, err := codec.Encode(original, 0)
	if err != nil {
		t.Fatal(err)
	}
	decoded, err := codec.Decode(encoded, 0)
	if err != nil {
		t.Fatal(err)
	}
	if decoded.Type != original.Type || decoded.Path != original.Path || decoded.Session != original.Session || decoded.Seq != original.Seq || !bytes.Equal(decoded.Payload, original.Payload) {
		t.Fatalf("roundtrip mismatch: %#v", decoded)
	}
	if _, err := codec.Decode(encoded, 1); err == nil {
		t.Fatal("direction must be authenticated by nonce")
	}
}
