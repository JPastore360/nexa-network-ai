package main

import (
	"log"
	"net"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)

type Endpoint struct {
	Addr     *net.UDPAddr
	LastSeen time.Time
}

type Session struct {
	ID        uint64
	Endpoints map[byte]Endpoint
	NextSeq   atomic.Uint64
}

type Server struct {
	conn      *net.UDPConn
	tun       *os.File
	codec     *Codec
	mu        sync.RWMutex
	sessions  map[uint64]*Session
	ipSession map[[4]byte]uint64
}

func main() {
	secret := os.Getenv("NEXA_KEY")
	if len(secret) < 12 {
		log.Fatal("NEXA_KEY deve ter pelo menos 12 caracteres")
	}
	port := envInt("NEXA_PORT", 51888)
	tunName := envString("NEXA_TUN", "nexa0")

	tun, err := openTun(tunName)
	if err != nil {
		log.Fatalf("abrindo TUN %s: %v", tunName, err)
	}
	addr := &net.UDPAddr{IP: net.IPv4zero, Port: port}
	conn, err := net.ListenUDP("udp4", addr)
	if err != nil {
		log.Fatal(err)
	}

	s := &Server{
		conn:      conn,
		tun:       tun,
		codec:     NewCodec(secret),
		sessions:  make(map[uint64]*Session),
		ipSession: make(map[[4]byte]uint64),
	}

	log.Printf("Nexa Network Server ouvindo UDP :%d / TUN %s", port, tunName)
	go s.tunLoop()
	s.udpLoop()
}

func (s *Server) udpLoop() {
	buf := make([]byte, 65535)
	for {
		n, addr, err := s.conn.ReadFromUDP(buf)
		if err != nil {
			log.Printf("UDP read: %v", err)
			continue
		}
		data := append([]byte(nil), buf[:n]...)
		msg, err := s.codec.Decode(data, 0)
		if err != nil {
			continue
		}
		s.touch(msg.Session, msg.Path, addr)

		switch msg.Type {
		case typePing:
			s.replyPong(msg, addr)
		case typeData:
			if src, ok := ipv4Source(msg.Payload); ok {
				s.mu.Lock()
				s.ipSession[src] = msg.Session
				s.mu.Unlock()
			}
			if _, err := s.tun.Write(msg.Payload); err != nil {
				log.Printf("TUN write: %v", err)
			}
		}
	}
}

func (s *Server) tunLoop() {
	buf := make([]byte, 65535)
	for {
		n, err := s.tun.Read(buf)
		if err != nil {
			log.Printf("TUN read: %v", err)
			continue
		}
		packet := append([]byte(nil), buf[:n]...)
		dst, ok := ipv4Destination(packet)
		if !ok {
			continue
		}
		session := s.sessionForIP(dst)
		if session == nil {
			continue
		}
		endpoint, path, ok := chooseEndpoint(session, packet)
		if !ok {
			continue
		}
		seq := session.NextSeq.Add(1)
		encoded, err := s.codec.Encode(Message{
			Type: typeData, Path: path, Session: session.ID, Seq: seq, Payload: packet,
		}, 1)
		if err != nil {
			continue
		}
		_, _ = s.conn.WriteToUDP(encoded, endpoint.Addr)
	}
}

func (s *Server) replyPong(msg Message, addr *net.UDPAddr) {
	session := s.ensureSession(msg.Session)
	seq := session.NextSeq.Add(1)
	encoded, err := s.codec.Encode(Message{
		Type: typePong, Path: msg.Path, Session: msg.Session, Seq: seq, Payload: msg.Payload,
	}, 1)
	if err == nil {
		_, _ = s.conn.WriteToUDP(encoded, addr)
	}
}

func (s *Server) touch(id uint64, path byte, addr *net.UDPAddr) {
	s.mu.Lock()
	defer s.mu.Unlock()
	session := s.sessions[id]
	if session == nil {
		session = &Session{ID: id, Endpoints: make(map[byte]Endpoint)}
		s.sessions[id] = session
		log.Printf("nova sessão %016x", id)
	}
	clone := *addr
	session.Endpoints[path] = Endpoint{Addr: &clone, LastSeen: time.Now()}
}

func (s *Server) ensureSession(id uint64) *Session {
	s.mu.Lock()
	defer s.mu.Unlock()
	session := s.sessions[id]
	if session == nil {
		session = &Session{ID: id, Endpoints: make(map[byte]Endpoint)}
		s.sessions[id] = session
	}
	return session
}

func (s *Server) sessionForIP(ip [4]byte) *Session {
	s.mu.RLock()
	defer s.mu.RUnlock()
	id, ok := s.ipSession[ip]
	if !ok {
		return nil
	}
	return s.sessions[id]
}

func chooseEndpoint(session *Session, packet []byte) (Endpoint, byte, bool) {
	now := time.Now()
	e1, ok1 := session.Endpoints[1]
	e2, ok2 := session.Endpoints[2]
	ok1 = ok1 && now.Sub(e1.LastSeen) < 12*time.Second
	ok2 = ok2 && now.Sub(e2.LastSeen) < 12*time.Second
	if !ok1 && !ok2 {
		return Endpoint{}, 0, false
	}
	if ok1 && !ok2 {
		return e1, 1, true
	}
	if ok2 && !ok1 {
		return e2, 2, true
	}
	if flowHash(packet)%2 == 0 {
		return e1, 1, true
	}
	return e2, 2, true
}

func flowHash(packet []byte) uint32 {
	if len(packet) < 20 || packet[0]>>4 != 4 {
		return 0
	}
	ihl := int(packet[0]&0x0f) * 4
	if ihl < 20 || len(packet) < ihl {
		return 0
	}
	var h uint32 = 2166136261
	feed := func(b byte) { h ^= uint32(b); h *= 16777619 }
	for i := 12; i <= 19; i++ {
		feed(packet[i])
	}
	feed(packet[9])
	proto := packet[9]
	if (proto == 6 || proto == 17) && len(packet) >= ihl+4 {
		for i := ihl; i < ihl+4; i++ {
			feed(packet[i])
		}
	}
	return h
}

func ipv4Source(packet []byte) ([4]byte, bool) {
	var out [4]byte
	if len(packet) < 20 || packet[0]>>4 != 4 {
		return out, false
	}
	copy(out[:], packet[12:16])
	return out, true
}

func ipv4Destination(packet []byte) ([4]byte, bool) {
	var out [4]byte
	if len(packet) < 20 || packet[0]>>4 != 4 {
		return out, false
	}
	copy(out[:], packet[16:20])
	return out, true
}

func envString(name, fallback string) string {
	if v := os.Getenv(name); v != "" {
		return v
	}
	return fallback
}

func envInt(name string, fallback int) int {
	if v := os.Getenv(name); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return fallback
}
