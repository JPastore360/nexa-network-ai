package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/binary"
	"errors"
)

const (
	magic      uint32 = 0x4E584E31
	version    byte   = 1
	typeData   byte   = 1
	typePing   byte   = 2
	typePong   byte   = 3
	headerSize        = 24
)

type Message struct {
	Type    byte
	Path    byte
	Session uint64
	Seq     uint64
	Payload []byte
}

type Codec struct {
	key [32]byte
}

func NewCodec(passphrase string) *Codec {
	return &Codec{key: sha256.Sum256([]byte(passphrase))}
}

func (c *Codec) aead() (cipher.AEAD, error) {
	block, err := aes.NewCipher(c.key[:])
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

func (c *Codec) Encode(msg Message, direction int) ([]byte, error) {
	header := make([]byte, headerSize)
	binary.BigEndian.PutUint32(header[0:4], magic)
	header[4] = version
	header[5] = msg.Type
	header[6] = msg.Path
	header[7] = 0
	binary.BigEndian.PutUint64(header[8:16], msg.Session)
	binary.BigEndian.PutUint64(header[16:24], msg.Seq)
	aead, err := c.aead()
	if err != nil {
		return nil, err
	}
	sealed := aead.Seal(nil, nonce(msg.Session, msg.Seq, direction), msg.Payload, header)
	return append(header, sealed...), nil
}

func (c *Codec) Decode(data []byte, direction int) (Message, error) {
	if len(data) < headerSize+16 {
		return Message{}, errors.New("short datagram")
	}
	if binary.BigEndian.Uint32(data[0:4]) != magic || data[4] != version {
		return Message{}, errors.New("bad header")
	}
	msg := Message{
		Type:    data[5],
		Path:    data[6],
		Session: binary.BigEndian.Uint64(data[8:16]),
		Seq:     binary.BigEndian.Uint64(data[16:24]),
	}
	aead, err := c.aead()
	if err != nil {
		return Message{}, err
	}
	plain, err := aead.Open(nil, nonce(msg.Session, msg.Seq, direction), data[headerSize:], data[:headerSize])
	if err != nil {
		return Message{}, err
	}
	msg.Payload = plain
	return msg, nil
}

func nonce(session, seq uint64, direction int) []byte {
	n := make([]byte, 12)
	hash := uint32(session ^ (session >> 32))
	if direction == 1 {
		hash ^= 0x80000000
	}
	binary.BigEndian.PutUint32(n[0:4], hash)
	binary.BigEndian.PutUint64(n[4:12], seq)
	return n
}
